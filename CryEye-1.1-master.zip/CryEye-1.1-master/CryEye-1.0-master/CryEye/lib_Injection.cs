using SDG.Unturned;
using System;
using System.Reflection;
using UnityEngine;

namespace CryEye
{
	public class lib_Injection : MonoBehaviour
	{
		private DateTime lastTime;

		public void Start()
		{
		}

		public void Update()
		{
			DateTime arg_07_0 = this.lastTime;
			bool flag = (DateTime.Now - this.lastTime).TotalMilliseconds >= 1000.0;
			if (flag)
			{
				bool flag2 = Provider.isPvP && (bool)ctrl_Connector.hack_Settings.getSetting("enable_instantDisconnect").value && ctrl_Connector.allow && !ctrl_Connector.hack_Main.banned_hack;
				if (flag2)
				{
					typeof(PlayerPauseUI).GetField("TIMER_LEAVE", BindingFlags.Static | BindingFlags.Public).SetValue(null, 0f);
				}
				else
				{
					typeof(PlayerPauseUI).GetField("TIMER_LEAVE", BindingFlags.Static | BindingFlags.Public).SetValue(null, 10f);
				}
			}
		}

		public void OnGUI()
		{
		}
	}
}
