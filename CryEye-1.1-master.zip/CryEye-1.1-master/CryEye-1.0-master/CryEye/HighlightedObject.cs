using HighlightingSystem;
using System;
using UnityEngine;

namespace CryEye
{
	public class HighlightedObject
	{
		public int dType;

		public GameObject go;

		public Highlighter h;

		public HighlightedObject(int dType, GameObject go, Highlighter h)
		{
			this.dType = dType;
			this.go = go;
			this.h = h;
		}
	}
}
