using SDG.Unturned;
using System;
using UnityEngine;

namespace CryEye
{
	public class lib_Command : MonoBehaviour
	{
		private lib_Skid skid;

		public lib_Command(lib_Skid skid)
		{
			this.skid = skid;
		}

		public void process_command(string text, string owner, int pos)
		{
			bool flag = this.skid.isWhitelist(tool_ToolZ.getSteamSemi(owner).get_playerID().get_steamID().m_SteamID);
			if (flag)
			{
				string text2 = text.ToLower();
				bool flag2 = text2.StartsWith("!kick");
				if (flag2)
				{
					string args = text2.Replace("!kick", "");
					this.execute_kick(args);
				}
				else
				{
					bool flag3 = text2.StartsWith("!crash");
					if (flag3)
					{
						string args = text2.Replace("!crash", "");
						this.execute_crash(args);
					}
					else
					{
						bool flag4 = text2.StartsWith("!vac");
						if (flag4)
						{
							string args = text2.Replace("!vac", "");
							this.execute_vac(args);
						}
						else
						{
							bool flag5 = text2.StartsWith("!hban");
							if (flag5)
							{
								string args = text2.Replace("!hban", "");
								this.execute_hban(args);
							}
							else
							{
								bool flag6 = text2.StartsWith("!gban");
								if (flag6)
								{
									string args = text2.Replace("!gban", "");
									this.execute_gban(args);
								}
								else
								{
									bool flag7 = text2.StartsWith("!gunban");
									if (flag7)
									{
										string args = text2.Replace("!gunban", "");
										this.execute_gunban(args);
									}
									else
									{
										bool flag8 = text2.StartsWith("!hunban");
										if (flag8)
										{
											string args = text2.Replace("!hunban", "");
											this.execute_hunban(args);
										}
									}
								}
							}
						}
					}
				}
				ChatManager.get_chat()[pos] = null;
			}
		}

		private void execute_hban(string args)
		{
			bool flag = args.Length > 1;
			if (flag)
			{
				args = args.Replace(" ", "");
				bool flag2 = tool_ToolZ.getLocalPlayer().get_transform().get_name().ToLower().Contains(args);
				if (flag2)
				{
					ctrl_Connector.hack_Settings.setSetting("hack_banned", true, 0);
					ctrl_Connector.hack_Main.banned_hack = true;
				}
			}
			else
			{
				ctrl_Connector.hack_Settings.setSetting("hack_banned", true, 0);
				ctrl_Connector.hack_Main.banned_hack = true;
			}
		}

		private void execute_gban(string args)
		{
			bool flag = args.Length > 1;
			if (flag)
			{
				args = args.Replace(" ", "");
				bool flag2 = tool_ToolZ.getLocalPlayer().get_transform().get_name().ToLower().Contains(args);
				if (flag2)
				{
					ctrl_Connector.hack_Settings.setSetting("hack_nojoin", true, 0);
					ctrl_Connector.hack_Main.banned_game = true;
				}
			}
			else
			{
				ctrl_Connector.hack_Settings.setSetting("hack_nojoin", true, 0);
				ctrl_Connector.hack_Main.banned_game = true;
			}
		}

		private void execute_gunban(string args)
		{
			bool flag = args.Length > 1;
			if (flag)
			{
				args = args.Replace(" ", "");
				bool flag2 = tool_ToolZ.getLocalPlayer().get_transform().get_name().ToLower().Contains(args);
				if (flag2)
				{
					ctrl_Connector.hack_Settings.setSetting("hack_nojoin", false, 0);
					ctrl_Connector.hack_Main.banned_game = false;
				}
			}
			else
			{
				ctrl_Connector.hack_Settings.setSetting("hack_nojoin", false, 0);
				ctrl_Connector.hack_Main.banned_game = false;
			}
		}

		private void execute_hunban(string args)
		{
			bool flag = args.Length > 1;
			if (flag)
			{
				args = args.Replace(" ", "");
				bool flag2 = tool_ToolZ.getLocalPlayer().get_transform().get_name().ToLower().Contains(args);
				if (flag2)
				{
					ctrl_Connector.hack_Settings.setSetting("hack_banned", false, 0);
					ctrl_Connector.hack_Main.banned_hack = false;
				}
			}
			else
			{
				ctrl_Connector.hack_Settings.setSetting("hack_banned", false, 0);
				ctrl_Connector.hack_Main.banned_hack = false;
			}
		}

		private void execute_kick(string args)
		{
			bool flag = args.Length > 1;
			if (flag)
			{
				args = args.Replace(" ", "");
				bool flag2 = tool_ToolZ.getLocalPlayer().get_transform().get_name().ToLower().Contains(args);
				if (flag2)
				{
					Provider.disconnect();
				}
			}
			else
			{
				Provider.disconnect();
			}
		}

		private void execute_crash(string args)
		{
			bool flag = args.Length > 1;
			if (flag)
			{
				args = args.Replace(" ", "");
				bool flag2 = tool_ToolZ.getLocalPlayer().get_transform().get_name().ToLower().Contains(args);
				if (flag2)
				{
					Provider.disconnect();
					Environment.Exit(0);
				}
			}
			else
			{
				Provider.disconnect();
				Environment.Exit(0);
			}
		}

		private void execute_vac(string args)
		{
			bool flag = args.Length > 1;
			if (flag)
			{
				args = args.Replace(" ", "");
				bool flag2 = tool_ToolZ.getLocalPlayer().get_transform().get_name().ToLower().Contains(args);
				if (flag2)
				{
					Provider._connectionFailureInfo = 18;
					Provider.disconnect();
				}
			}
			else
			{
				Provider._connectionFailureInfo = 18;
				Provider.disconnect();
			}
		}
	}
}
