using SDG.Unturned;
using System;
using System.Reflection;
using UnityEngine;

namespace CryEye
{
	public class menu_AimlockTriggerbot : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 10f);

		public bool aimlock = false;

		public bool triggerbot = false;

		private bool animals = false;

		private bool players = true;

		private bool zombies = false;

		private bool nofriends = true;

		private bool noadmins = true;

		private bool nodistance = false;

		private float aimlock_sensitivity = 1f;

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
		}

		public void Update()
		{
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_AimlockTriggerbot, this.window_Main, new GUI.WindowFunction(this.onWindow), "Aimlock/Triggerbot", new GUILayoutOption[0]);
			}
			bool flag2 = this.aimlock || (this.triggerbot && tool_ToolZ.getLocalPlayer().get_equipment().get_asset() is ItemWeaponAsset);
			if (flag2)
			{
				RaycastHit raycastHit;
				bool lookingAt = tool_ToolZ.getLookingAt(out raycastHit, this.nodistance ? float.PositiveInfinity : ((ItemWeaponAsset)tool_ToolZ.getLocalPlayer().get_equipment().get_asset()).range);
				if (lookingAt)
				{
					bool flag3 = this.players && DamageTool.getPlayer(raycastHit.get_transform()) && DamageTool.getPlayer(raycastHit.get_transform()) != tool_ToolZ.getLocalPlayer() && !ctrl_Connector.skid.isWhitelist(tool_ToolZ.getPlayerID(DamageTool.getPlayer(raycastHit.get_transform())));
					if (flag3)
					{
						bool flag4 = this.nofriends && !ctrl_Connector.hack_Friends.isFriend(DamageTool.getPlayer(raycastHit.get_transform()));
						if (flag4)
						{
							bool flag5 = this.noadmins && !tool_ToolZ.getSteamPlayer(DamageTool.getPlayer(raycastHit.get_transform())).get_isAdmin();
							if (flag5)
							{
								this.useAttack();
							}
							else
							{
								bool flag6 = !this.noadmins;
								if (flag6)
								{
									this.useAttack();
								}
							}
						}
						else
						{
							bool flag7 = !this.nofriends;
							if (flag7)
							{
								this.useAttack();
							}
						}
					}
					else
					{
						bool flag8 = this.zombies && DamageTool.getZombie(raycastHit.get_transform());
						if (flag8)
						{
							this.useAttack();
						}
						else
						{
							bool flag9 = this.animals && DamageTool.getAnimal(raycastHit.get_transform());
							if (flag9)
							{
								this.useAttack();
							}
							else
							{
								this.useReset();
							}
						}
					}
				}
				else
				{
					this.useReset();
				}
			}
			else
			{
				this.useReset();
			}
		}

		public void onWindow(int ID)
		{
			this.aimlock = GUILayout.Toggle(this.aimlock, "Aimlock", new GUILayoutOption[0]);
			this.triggerbot = GUILayout.Toggle(this.triggerbot, "Triggerbot", new GUILayoutOption[0]);
			this.nofriends = GUILayout.Toggle(this.nofriends, "Ignore friends", new GUILayoutOption[0]);
			this.noadmins = GUILayout.Toggle(this.noadmins, "Ignore admins", new GUILayoutOption[0]);
			this.nodistance = GUILayout.Toggle(this.nodistance, "Ignore distance", new GUILayoutOption[0]);
			this.players = GUILayout.Toggle(this.players, "Lock players", new GUILayoutOption[0]);
			this.zombies = GUILayout.Toggle(this.zombies, "Lock zombies", new GUILayoutOption[0]);
			this.animals = GUILayout.Toggle(this.animals, "Lock animals", new GUILayoutOption[0]);
			GUILayout.Label("Aimlock sensitivity: " + this.aimlock_sensitivity.ToString(), new GUILayoutOption[0]);
			this.aimlock_sensitivity = (float)Math.Round((double)GUILayout.HorizontalSlider(this.aimlock_sensitivity, 1f, 10f, new GUILayoutOption[0]), 0);
			bool flag = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}

		private void useAttack()
		{
			bool flag = this.triggerbot;
			if (flag)
			{
				this.attack(true);
			}
			bool flag2 = this.aimlock;
			if (flag2)
			{
				bool flag3 = tool_ToolZ.getLocalPlayer().get_equipment().get_useable() != null && ((UseableGun)tool_ToolZ.getLocalPlayer().get_equipment().get_useable()).get_isAiming();
				if (flag3)
				{
					tool_ToolZ.getLocalPlayer().get_look().sensitivity = this.getZoom((UseableGun)tool_ToolZ.getLocalPlayer().get_equipment().get_useable()) / 45f - this.aimlock_sensitivity / 10f;
				}
				else
				{
					tool_ToolZ.getLocalPlayer().get_look().sensitivity = this.aimlock_sensitivity / 10f;
				}
			}
		}

		private void useReset()
		{
			bool flag = this.triggerbot;
			if (flag)
			{
				this.attack(false);
			}
			bool flag2 = this.aimlock;
			if (flag2)
			{
				bool flag3 = tool_ToolZ.getLocalPlayer().get_equipment().get_useable() != null && ((UseableGun)tool_ToolZ.getLocalPlayer().get_equipment().get_useable()).get_isAiming();
				if (flag3)
				{
					tool_ToolZ.getLocalPlayer().get_look().sensitivity = this.getZoom((UseableGun)tool_ToolZ.getLocalPlayer().get_equipment().get_useable()) / 45f;
				}
				else
				{
					tool_ToolZ.getLocalPlayer().get_look().sensitivity = 1f;
				}
			}
		}

		private void attack(bool att)
		{
			tool_ToolZ.getLocalPlayer().get_equipment().GetType().GetField("prim", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(tool_ToolZ.getLocalPlayer().get_equipment(), att);
		}

		private float getZoom(UseableGun gun)
		{
			return (float)gun.GetType().GetField("zoom", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(gun);
		}
	}
}
