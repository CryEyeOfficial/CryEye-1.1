using SDG.Unturned;
using System;

namespace CryEye
{
	public class WepAssetInfo
	{
		public float range;

		public byte[] hash;

		public WepAssetInfo(ItemMeleeAsset iwa)
		{
			this.range = iwa.range;
			this.hash = iwa.get_hash();
		}
	}
}
