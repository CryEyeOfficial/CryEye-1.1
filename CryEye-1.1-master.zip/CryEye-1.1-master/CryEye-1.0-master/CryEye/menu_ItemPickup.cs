using SDG.Unturned;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace CryEye
{
	public class menu_ItemPickup : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 10f);

		public bool itemPickup = false;

		private bool ignoreInvalidAmmo = true;

		private bool ignoreDropped = true;

		private int checkTime = 1000;

		private bool ignoreWalls = true;

		private DateTime lastCheck;

		private menu_ItemSelection itemsel;

		private List<ItemAsset> dropped = new List<ItemAsset>();

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
			this.itemsel = ctrl_Connector.hack_ItemSelection;
		}

		public void Update()
		{
			bool flag = this.itemPickup;
			if (flag)
			{
				DateTime arg_12_0 = this.lastCheck;
				bool flag2 = (DateTime.Now - this.lastCheck).TotalMilliseconds >= (double)this.checkTime;
				if (flag2)
				{
					InteractableItem[] items = this.getItems();
					for (int i = 0; i < items.Length; i++)
					{
						items[i].use();
					}
					this.lastCheck = DateTime.Now;
				}
			}
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_ItemPickup, this.window_Main, new GUI.WindowFunction(this.onWindow), "Auto Item Pickup Menu", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			this.itemPickup = GUILayout.Toggle(this.itemPickup, "Auto Item Pickup", new GUILayoutOption[0]);
			this.ignoreWalls = GUILayout.Toggle(this.ignoreWalls, "Pickup Through Walls", new GUILayoutOption[0]);
			GUILayout.Label("Item check time(miliseconds): " + this.checkTime, new GUILayoutOption[0]);
			this.checkTime = (int)Math.Round((double)GUILayout.HorizontalSlider((float)this.checkTime, 1f, 2000f, new GUILayoutOption[0]));
			bool flag = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}

		private InteractableItem[] getItems()
		{
			Collider[] array = Physics.OverlapSphere(tool_ToolZ.getLocalPlayer().get_look().get_aim().get_position(), 10f, RayMasks.ITEM);
			List<InteractableItem> list = new List<InteractableItem>();
			bool flag = this.itemsel.guns || this.itemsel.melee || this.itemsel.ammo || this.itemsel.attachments || this.itemsel.throwable || this.itemsel.clothing || this.itemsel.bags || this.itemsel.medical || this.itemsel.foodnwater || this.itemsel.custom;
			if (flag)
			{
				for (int i = 0; i < array.Length; i++)
				{
					bool flag2 = array[i] != null && array[i].get_gameObject() != null;
					if (flag2)
					{
						InteractableItem component = array[i].GetComponent<InteractableItem>();
						bool flag3 = component != null && tool_ToolZ.noWall(component.get_transform(), float.PositiveInfinity);
						if (flag3)
						{
							bool flag4 = this.itemsel.guns && component.asset is ItemGunAsset;
							if (flag4)
							{
								list.Add(component);
							}
							else
							{
								bool flag5 = this.itemsel.melee && component.asset is ItemMeleeAsset;
								if (flag5)
								{
									list.Add(component);
								}
								else
								{
									bool flag6 = this.itemsel.ammo && component.asset is ItemMagazineAsset;
									if (flag6)
									{
										list.Add(component);
									}
									else
									{
										bool flag7 = this.itemsel.attachments && (component.asset is ItemBarrelAsset || component.asset is ItemCaliberAsset || component.asset is ItemGripAsset || component.asset is ItemOpticAsset || component.asset is ItemTacticalAsset);
										if (flag7)
										{
											list.Add(component);
										}
										else
										{
											bool flag8 = this.itemsel.throwable && component.asset is ItemThrowableAsset;
											if (flag8)
											{
												list.Add(component);
											}
											else
											{
												bool flag9 = this.itemsel.clothing && (component.asset is ItemHatAsset || component.asset is ItemGlassesAsset || component.asset is ItemMaskAsset || component.asset is ItemShirtAsset || component.asset is ItemPantsAsset || component.asset is ItemClothingAsset);
												if (flag9)
												{
													list.Add(component);
												}
												else
												{
													bool flag10 = this.itemsel.bags && component.asset is ItemBackpackAsset;
													if (flag10)
													{
														list.Add(component);
													}
													else
													{
														bool flag11 = this.itemsel.medical && component.asset is ItemMedicalAsset;
														if (flag11)
														{
															list.Add(component);
														}
														else
														{
															bool flag12 = this.itemsel.foodnwater && component.asset is ItemConsumeableAsset;
															if (flag12)
															{
																list.Add(component);
															}
															else
															{
																bool flag13 = this.itemsel.custom && ctrl_Connector.hack_CustomItem.existsCustomItem(component.item.get_id());
																if (flag13)
																{
																	list.Add(component);
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return list.ToArray();
		}
	}
}
