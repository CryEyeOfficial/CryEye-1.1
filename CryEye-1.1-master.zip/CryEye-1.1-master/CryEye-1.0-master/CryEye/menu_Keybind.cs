using SDG.Unturned;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace CryEye
{
	public class menu_Keybind : MonoBehaviour
	{
		[CompilerGenerated]
		[Serializable]
		private sealed class <>c
		{
			public static readonly menu_Keybind.<>c <>9 = new menu_Keybind.<>c();

			public static Predicate<Keybind> <>9__14_1;

			public static Predicate<Keybind> <>9__14_2;

			public static Predicate<Keybind> <>9__14_3;

			internal bool <Update>b__14_1(Keybind a)
			{
				return a.getting;
			}

			internal bool <Update>b__14_2(Keybind a)
			{
				return a.getting;
			}

			internal bool <Update>b__14_3(Keybind a)
			{
				return a.getting;
			}
		}

		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 10f);

		private List<Keybind> keybinds = new List<Keybind>();

		private bool rebinding = false;

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		private void loadKeybinds()
		{
			bool flag = lib_FileSystem.existKeybinds();
			if (flag)
			{
				try
				{
					this.keybinds = lib_FileSystem.readKeybinds();
				}
				catch (Exception ex)
				{
					Debug.LogException(ex);
					lib_FileSystem.deleteKeybinds();
					this.loadKeybinds();
					return;
				}
				this.checkKeybinds();
			}
			else
			{
				this.setKeybind("menu", "Main Menu", 282);
				this.setKeybind("aimbot", "Aimbot", 0);
				this.setKeybind("triggerbot", "Triggerbot", 0);
				this.setKeybind("aimlock", "Aimlock", 0);
				this.setKeybind("autoitempickup", "Auto Item Pickup", 0);
			}
		}

		private void checkKeybinds()
		{
			bool flag = !this.keybindExists("menu") || !this.keybindExists("aimbot") || !this.keybindExists("triggerbot") || !this.keybindExists("aimlock") || !this.keybindExists("autoitempickup");
			if (flag)
			{
				lib_FileSystem.deleteKeybinds();
				this.loadKeybinds();
			}
		}

		private void setKeybind(string name, string text, int key = 0)
		{
			bool flag = this.keybindExists(name);
			if (flag)
			{
				Array.Find<Keybind>(this.keybinds.ToArray(), (Keybind a) => a.name == name).key = key;
			}
			else
			{
				this.keybinds.Add(new Keybind(name, text, key));
			}
			this.saveKeybinds();
		}

		private void saveKeybinds()
		{
			lib_FileSystem.writeKeybinds(this.keybinds.ToArray());
		}

		private bool keybindExists(string name)
		{
			return Array.Exists<Keybind>(this.keybinds.ToArray(), (Keybind a) => a.name == name);
		}

		private void useKey(string name)
		{
			bool flag = name == "menu";
			if (flag)
			{
				ctrl_Connector.hack_Main.toggleOn();
				ctrl_Connector.isOn = !ctrl_Connector.isOn;
			}
			else
			{
				bool flag2 = name == "aimbot";
				if (flag2)
				{
					bool flag3 = ctrl_Connector.isPremium(Provider.get_client().m_SteamID);
					if (flag3)
					{
						ctrl_Connector.hack_Aimbot.enabled = !ctrl_Connector.hack_Aimbot.enabled;
					}
				}
				else
				{
					bool flag4 = name == "triggerbot";
					if (flag4)
					{
						ctrl_Connector.hack_AimlockTriggerbot.triggerbot = !ctrl_Connector.hack_AimlockTriggerbot.triggerbot;
					}
					else
					{
						bool flag5 = name == "aimlock";
						if (flag5)
						{
							ctrl_Connector.hack_AimlockTriggerbot.aimlock = !ctrl_Connector.hack_AimlockTriggerbot.aimlock;
						}
						else
						{
							bool flag6 = name == "autoitempickup";
							if (flag6)
							{
								ctrl_Connector.hack_ItemPickup.itemPickup = !ctrl_Connector.hack_ItemPickup.itemPickup;
							}
						}
					}
				}
			}
		}

		public void Start()
		{
			this.isOn = false;
			this.loadKeybinds();
		}

		public void Update()
		{
			Event current = Event.get_current();
			bool flag = current.get_type() == 4;
			if (flag)
			{
				KeyCode k = current.get_keyCode();
				Debug.Log("KEY PRESSED : " + k);
				Debug.Log(Array.Exists<Keybind>(this.keybinds.ToArray(), (Keybind a) => a.key != null && a.key == k));
				bool flag2 = this.rebinding;
				if (flag2)
				{
					bool flag3 = k == 27 || k == 8;
					if (flag3)
					{
						Keybind[] arg_C1_0 = this.keybinds.ToArray();
						Predicate<Keybind> arg_C1_1;
						if ((arg_C1_1 = menu_Keybind.<>c.<>9__14_1) == null)
						{
							arg_C1_1 = (menu_Keybind.<>c.<>9__14_1 = new Predicate<Keybind>(menu_Keybind.<>c.<>9.<Update>b__14_1));
						}
						Array.Find<Keybind>(arg_C1_0, arg_C1_1).key = 0;
					}
					else
					{
						Keybind[] arg_FA_0 = this.keybinds.ToArray();
						Predicate<Keybind> arg_FA_1;
						if ((arg_FA_1 = menu_Keybind.<>c.<>9__14_2) == null)
						{
							arg_FA_1 = (menu_Keybind.<>c.<>9__14_2 = new Predicate<Keybind>(menu_Keybind.<>c.<>9.<Update>b__14_2));
						}
						Array.Find<Keybind>(arg_FA_0, arg_FA_1).key = k;
					}
					Keybind[] arg_135_0 = this.keybinds.ToArray();
					Predicate<Keybind> arg_135_1;
					if ((arg_135_1 = menu_Keybind.<>c.<>9__14_3) == null)
					{
						arg_135_1 = (menu_Keybind.<>c.<>9__14_3 = new Predicate<Keybind>(menu_Keybind.<>c.<>9.<Update>b__14_3));
					}
					Array.Find<Keybind>(arg_135_0, arg_135_1).getting = false;
					this.rebinding = false;
					this.saveKeybinds();
				}
				else
				{
					bool flag4 = Array.Exists<Keybind>(this.keybinds.ToArray(), (Keybind a) => a.key != null && a.key == k);
					if (flag4)
					{
						this.useKey(Array.Find<Keybind>(this.keybinds.ToArray(), (Keybind a) => a.key != null && a.key == k).name);
					}
				}
			}
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_Keybind, this.window_Main, new GUI.WindowFunction(this.onWindow), "Keybind Menu", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			foreach (Keybind current in this.keybinds)
			{
				bool flag = GUILayout.Button(current.getting ? "Press any key" : (current.text + ": " + current.key), new GUILayoutOption[0]);
				if (flag)
				{
					this.rebinding = true;
					current.getting = true;
				}
			}
			bool flag2 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag2)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}
	}
}
