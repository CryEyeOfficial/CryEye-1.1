using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace CryEye
{
	public class lib_FileSystem
	{
		private static string cDir = Directory.GetCurrentDirectory();

		private static string sDir = Application.get_persistentDataPath();

		private static string file_Settings = lib_FileSystem.sDir + "\\Settings.dat";

		private static string file_Friends = lib_FileSystem.sDir + "\\Friends.dat";

		private static string file_Keybinds = lib_FileSystem.sDir + "\\Keybinds.dat";

		private static string file_CustomItem = lib_FileSystem.sDir + "\\CustomItem.dat";

		public static void writeSettings(Setting[] lines)
		{
			File.WriteAllText(lib_FileSystem.file_Settings, JsonConvert.SerializeObject(lines));
		}

		public static List<Setting> readSettings()
		{
			return JsonConvert.DeserializeObject<List<Setting>>(File.ReadAllText(lib_FileSystem.file_Settings));
		}

		public static bool existSettings()
		{
			return File.Exists(lib_FileSystem.file_Settings);
		}

		public static void deleteSettings()
		{
			File.Delete(lib_FileSystem.file_Settings);
		}

		public static void writeCustomItem(ushort[] lines)
		{
			File.WriteAllText(lib_FileSystem.file_CustomItem, JsonConvert.SerializeObject(lines));
		}

		public static List<ushort> readCustomItem()
		{
			return JsonConvert.DeserializeObject<List<ushort>>(File.ReadAllText(lib_FileSystem.file_CustomItem));
		}

		public static bool existCustomItem()
		{
			return File.Exists(lib_FileSystem.file_CustomItem);
		}

		public static void deleteCustomItem()
		{
			File.Delete(lib_FileSystem.file_CustomItem);
		}

		public static void createCustomItem()
		{
			File.WriteAllText(lib_FileSystem.file_CustomItem, "[]");
		}

		public static void writeKeybinds(Keybind[] lines)
		{
			File.WriteAllText(lib_FileSystem.file_Keybinds, JsonConvert.SerializeObject(lines));
		}

		public static List<Keybind> readKeybinds()
		{
			return JsonConvert.DeserializeObject<List<Keybind>>(File.ReadAllText(lib_FileSystem.file_Keybinds));
		}

		public static bool existKeybinds()
		{
			return File.Exists(lib_FileSystem.file_Keybinds);
		}

		public static void deleteKeybinds()
		{
			File.Delete(lib_FileSystem.file_Keybinds);
		}

		public static void writeFriends(Friend[] lines)
		{
			string contents = JsonConvert.SerializeObject(lines);
			File.WriteAllText(lib_FileSystem.file_Friends, contents);
		}

		public static List<Friend> readFriends()
		{
			return JsonConvert.DeserializeObject<List<Friend>>(File.ReadAllText(lib_FileSystem.file_Friends));
		}

		public static bool existFriends()
		{
			return File.Exists(lib_FileSystem.file_Friends);
		}

		public static void createFriends()
		{
			File.WriteAllText(lib_FileSystem.file_Friends, "[]");
		}

		public static void deleteFriends()
		{
			File.Delete(lib_FileSystem.file_Friends);
		}
	}
}
