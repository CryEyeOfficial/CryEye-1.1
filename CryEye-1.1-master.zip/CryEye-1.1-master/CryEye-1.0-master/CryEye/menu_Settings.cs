using System;
using System.Collections.Generic;
using UnityEngine;

namespace CryEye
{
	public class menu_Settings : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 10f);

		private List<Setting> settings = new List<Setting>();

		private DateTime lastCheck;

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
			this.loadSettings();
		}

		public void Update()
		{
			DateTime arg_07_0 = this.lastCheck;
			bool flag = (DateTime.Now - this.lastCheck).TotalMilliseconds >= 10000.0;
			if (flag)
			{
				bool flag2 = (bool)this.getSetting("sys_reset").value != ctrl_Connector.reset;
				if (flag2)
				{
					ctrl_Connector.reset = (bool)this.getSetting("sys_reset").value;
				}
				this.lastCheck = DateTime.Now;
			}
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_Settings, this.window_Main, new GUI.WindowFunction(this.onWindow), "Settings Menu", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			bool flag = GUILayout.Button(((!(bool)this.getSetting("enable_instantDisconnect").value) ? "Enable" : "Disable") + " Instant Disconnect", new GUILayoutOption[0]);
			if (flag)
			{
				this.setSetting("enable_instantDisconnect", !(bool)this.getSetting("enable_instantDisconnect").value, 0);
			}
			bool flag2 = GUILayout.Button(((!(bool)this.getSetting("sys_reset").value) ? "Enable" : "Disable") + " Hack Reset", new GUILayoutOption[0]);
			if (flag2)
			{
				this.setSetting("sys_reset", !(bool)this.getSetting("sys_reset").value, 0);
			}
			bool flag3 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag3)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}

		private void checkSettings()
		{
			bool flag = !this.settingExists("enable_smartUI") || !this.settingExists("enable_instantDisconnect") || !this.settingExists("hack_banned") || !this.settingExists("hack_nojoin") || !this.settingExists("sys_reset");
			if (flag)
			{
				lib_FileSystem.deleteSettings();
				this.loadSettings();
			}
		}

		public void loadSettings()
		{
			bool flag = lib_FileSystem.existSettings();
			if (flag)
			{
				try
				{
					this.settings = lib_FileSystem.readSettings();
				}
				catch (Exception ex)
				{
					Debug.LogException(ex);
					lib_FileSystem.deleteSettings();
					this.loadSettings();
					return;
				}
				this.checkSettings();
			}
			else
			{
				this.setSetting("enable_smartUI", false, 0);
				this.setSetting("enable_instantDisconnect", true, 0);
				this.setSetting("hack_banned", false, 2);
				this.setSetting("hack_nojoin", false, 2);
				this.setSetting("sys_reset", false, 0);
			}
		}

		public void saveSettings()
		{
			lib_FileSystem.writeSettings(this.settings.ToArray());
		}

		public void setSetting(string name, object value, int type = 0)
		{
			bool flag = this.settingExists(name);
			if (flag)
			{
				Array.Find<Setting>(this.settings.ToArray(), (Setting a) => a.name == name).value = value;
			}
			else
			{
				this.settings.Add(new Setting(name, value, type));
			}
			this.saveSettings();
		}

		public bool settingExists(string name)
		{
			return Array.Exists<Setting>(this.settings.ToArray(), (Setting a) => a.name == name);
		}

		public Setting getSetting(string name)
		{
			bool flag = this.settingExists(name);
			Setting result;
			if (flag)
			{
				result = Array.Find<Setting>(this.settings.ToArray(), (Setting a) => a.name == name);
			}
			else
			{
				result = new Setting(name, "ERROR", 0);
			}
			return result;
		}

		public Setting[] getSettings()
		{
			return this.settings.ToArray();
		}
	}
}
