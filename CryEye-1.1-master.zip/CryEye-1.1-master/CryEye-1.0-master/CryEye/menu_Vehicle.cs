using SDG.Unturned;
using System;
using System.Reflection;
using UnityEngine;

namespace CryEye
{
	public class menu_Vehicle : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 10f);

		private InteractableVehicle car;

		private EEngine startEngine = 2;

		private bool car_load = false;

		private bool fly = false;

		private float car_speed = 0f;

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
		}

		public void Update()
		{
			this.car = tool_ToolZ.getLocalPlayer().get_movement().getVehicle();
			bool flag = this.car == null;
			if (flag)
			{
				this.fly = false;
				this.car_load = false;
			}
			else
			{
				bool flag2 = !this.car_load;
				if (flag2)
				{
					this.startEngine = this.car.get_asset().get_engine();
					this.car_load = true;
				}
				bool keyDown = Input.GetKeyDown(ControlsSettings.get_interact());
				if (keyDown)
				{
					VehicleManager.exitVehicle();
				}
			}
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_Vehicle, this.window_Main, new GUI.WindowFunction(this.onWindow), "Vehicle Hack Menu", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			bool flag = !this.car_load;
			if (flag)
			{
				GUILayout.Label("Please enter a vehicle!", new GUILayoutOption[0]);
			}
			else
			{
				bool flag2 = ctrl_Connector.isPremium(Provider.get_client().m_SteamID);
				if (flag2)
				{
					bool flag3 = GUILayout.Button(((!this.fly) ? "Enable" : "Disable") + " flight", new GUILayoutOption[0]);
					if (flag3)
					{
						this.fly = !this.fly;
						bool flag4 = this.car.get_asset().get_engine() == this.startEngine;
						if (flag4)
						{
							this.setEngine(1);
							this.setLockMouse(true);
							this.car.GetComponent<Rigidbody>().set_useGravity(false);
						}
						else
						{
							this.setEngine(this.startEngine);
							this.setLockMouse(false);
							this.car.GetComponent<Rigidbody>().set_useGravity(true);
						}
					}
				}
				this.car_speed = this.car.get_asset().get_speedMax();
				GUILayout.Label("Max speed: " + this.car.get_asset().get_speedMax(), new GUILayoutOption[0]);
				this.car_speed = (float)Math.Round((double)GUILayout.HorizontalSlider(this.car_speed, 1f, 18f, new GUILayoutOption[0]), 1);
				this.updateMaxSpeed();
			}
			bool flag5 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag5)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}

		private void setEngine(EEngine engine)
		{
			VehicleAsset asset = this.car.get_asset();
			asset.GetType().GetField("_engine", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).SetValue(asset, engine);
		}

		private void setLockMouse(bool lockMouse)
		{
			VehicleAsset asset = this.car.get_asset();
			asset.GetType().GetField("_hasLockMouse", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).SetValue(asset, lockMouse);
		}

		private void updateMaxSpeed()
		{
			VehicleAsset asset = this.car.get_asset();
			asset.GetType().GetField("_speedMax", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).SetValue(asset, this.car_speed);
		}
	}
}
