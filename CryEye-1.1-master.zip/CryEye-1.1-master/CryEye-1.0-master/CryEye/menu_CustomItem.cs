using System;
using System.Collections.Generic;
using UnityEngine;

namespace CryEye
{
	public class menu_CustomItem : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 200f);

		private Vector2 scroll;

		private List<ushort> items = new List<ushort>();

		private string text = "";

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		private void loadCustomItem()
		{
			bool flag = lib_FileSystem.existCustomItem();
			if (flag)
			{
				try
				{
					this.items = lib_FileSystem.readCustomItem();
				}
				catch (Exception var_1_1A)
				{
					lib_FileSystem.deleteCustomItem();
					this.loadCustomItem();
				}
			}
			else
			{
				lib_FileSystem.createCustomItem();
			}
		}

		private void saveCustomItem()
		{
			lib_FileSystem.writeCustomItem(this.items.ToArray());
		}

		private void addCustomItem(ushort id)
		{
			this.items.Add(id);
			this.saveCustomItem();
		}

		private void removeCustomItem(ushort id)
		{
			this.items.Remove(id);
			this.saveCustomItem();
		}

		public bool existsCustomItem(ushort id)
		{
			return Array.Exists<ushort>(this.items.ToArray(), (ushort a) => a == id);
		}

		public ushort[] getCustomItem()
		{
			return this.items.ToArray();
		}

		public void Start()
		{
			this.isOn = false;
			this.loadCustomItem();
		}

		public void Update()
		{
			bool flag = Event.get_current().get_type() == 4 && Event.get_current().get_character() == '\n';
			if (flag)
			{
				bool flag2 = this.text != "" && this.text != null;
				if (flag2)
				{
					ushort id;
					bool flag3 = ushort.TryParse(this.text, out id);
					if (flag3)
					{
						this.addCustomItem(id);
					}
					this.text = "";
				}
			}
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_CustomItem, this.window_Main, new GUI.WindowFunction(this.onWindow), "Custom Item Selection", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			this.text = GUILayout.TextField(this.text, new GUILayoutOption[0]);
			this.scroll = GUILayout.BeginScrollView(this.scroll, new GUILayoutOption[0]);
			foreach (ushort current in this.items)
			{
				bool flag = GUILayout.Button(current.ToString(), new GUILayoutOption[0]);
				if (flag)
				{
					this.removeCustomItem(current);
				}
			}
			GUILayout.EndScrollView();
			bool flag2 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag2)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}
	}
}
