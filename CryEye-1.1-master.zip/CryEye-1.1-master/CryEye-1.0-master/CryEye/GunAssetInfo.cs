using SDG.Unturned;
using System;

namespace CryEye
{
	public class GunAssetInfo
	{
		public float recoilMax_x;

		public float recoilMax_y;

		public float recoilMin_x;

		public float recoilMin_y;

		public float spreadAim;

		public float spreadHip;

		public byte _firerate;

		public byte[] hash;

		public GunAssetInfo(ItemGunAsset iga)
		{
			this.recoilMax_x = iga.recoilMax_x;
			this.recoilMax_y = iga.recoilMax_y;
			this.recoilMin_x = iga.recoilMin_x;
			this.recoilMin_y = iga.recoilMin_y;
			this.spreadAim = iga.spreadAim;
			this.spreadHip = iga.spreadHip;
			this._firerate = iga.firerate;
			this.hash = iga.get_hash();
		}
	}
}
