using SDG.Unturned;
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CryEye
{
	public class menu_Weapons : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 10f);

		private bool norecoil = true;

		private bool nospread = true;

		private bool rapidfire = false;

		private float new_range = 0f;

		private List<GunAssetInfo> backups_Asset = new List<GunAssetInfo>();

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
		}

		private bool isBackupAsset(ItemGunAsset asset)
		{
			return Array.Exists<GunAssetInfo>(this.backups_Asset.ToArray(), (GunAssetInfo a) => a.hash == asset.get_hash());
		}

		private GunAssetInfo getGunAsset(ItemGunAsset asset)
		{
			return Array.Find<GunAssetInfo>(this.backups_Asset.ToArray(), (GunAssetInfo a) => a.hash == asset.get_hash());
		}

		public void Update()
		{
			bool flag = tool_ToolZ.getLocalPlayer().get_equipment().get_asset() is ItemGunAsset;
			if (flag)
			{
				ItemGunAsset itemGunAsset = (ItemGunAsset)tool_ToolZ.getLocalPlayer().get_equipment().get_asset();
				bool flag2 = this.nospread;
				if (flag2)
				{
					bool flag3 = !this.isBackupAsset(itemGunAsset);
					if (flag3)
					{
						this.backups_Asset.Add(new GunAssetInfo(itemGunAsset));
					}
					itemGunAsset.spreadAim = 0f;
					itemGunAsset.spreadHip = 0f;
				}
				bool flag4 = this.norecoil;
				if (flag4)
				{
					bool flag5 = !this.isBackupAsset(itemGunAsset);
					if (flag5)
					{
						this.backups_Asset.Add(new GunAssetInfo(itemGunAsset));
					}
					itemGunAsset.recoilMax_x = 0f;
					itemGunAsset.recoilMax_y = 0f;
					itemGunAsset.recoilMin_x = 0f;
					itemGunAsset.recoilMin_y = 0f;
				}
				bool flag6 = !this.nospread;
				if (flag6)
				{
					bool flag7 = this.isBackupAsset(itemGunAsset);
					if (flag7)
					{
						GunAssetInfo gunAsset = this.getGunAsset(itemGunAsset);
						itemGunAsset.recoilMax_x = gunAsset.recoilMax_x;
						itemGunAsset.recoilMax_y = gunAsset.recoilMax_y;
						itemGunAsset.recoilMin_x = gunAsset.recoilMin_x;
						itemGunAsset.recoilMin_y = gunAsset.recoilMin_y;
					}
				}
				bool flag8 = !this.norecoil;
				if (flag8)
				{
					bool flag9 = this.isBackupAsset(itemGunAsset);
					if (flag9)
					{
						GunAssetInfo gunAsset2 = this.getGunAsset(itemGunAsset);
						itemGunAsset.spreadAim = gunAsset2.spreadAim;
						itemGunAsset.spreadHip = gunAsset2.spreadHip;
					}
				}
			}
			bool flag10 = tool_ToolZ.getLocalPlayer().get_equipment().get_useable() is UseableGun;
			if (flag10)
			{
				UseableGun useableGun = (UseableGun)tool_ToolZ.getLocalPlayer().get_equipment().get_useable();
				bool flag11 = this.rapidfire;
				if (flag11)
				{
					useableGun.GetType().GetField("firemode", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(useableGun, 2);
				}
			}
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_Weapons, this.window_Main, new GUI.WindowFunction(this.onWindow), "Weapons Hack Menu", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			this.norecoil = GUILayout.Toggle(this.norecoil, "NoRecoil", new GUILayoutOption[0]);
			this.nospread = GUILayout.Toggle(this.nospread, "NoSpread", new GUILayoutOption[0]);
			this.rapidfire = GUILayout.Toggle(this.rapidfire, "RapidFire", new GUILayoutOption[0]);
			bool flag = tool_ToolZ.getLocalPlayer().get_equipment().get_asset() != null && tool_ToolZ.getLocalPlayer().get_equipment().get_asset() is ItemWeaponAsset && tool_ToolZ.getLocalPlayer().get_equipment().get_asset() is ItemMeleeAsset;
			if (flag)
			{
				ItemWeaponAsset itemWeaponAsset = (ItemWeaponAsset)tool_ToolZ.getLocalPlayer().get_equipment().get_asset();
				this.new_range = itemWeaponAsset.range;
				GUILayout.Label("Reach: " + itemWeaponAsset.range, new GUILayoutOption[0]);
				this.new_range = (float)Math.Round((double)GUILayout.HorizontalSlider(this.new_range, 1f, 26f, new GUILayoutOption[0]), 0);
				this.updateFarReach();
			}
			bool flag2 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag2)
			{
				this.isOn = false;
			}
			GUI.DragWindow();
		}

		private void updateFarReach()
		{
			typeof(ItemWeaponAsset).GetField("range", BindingFlags.Instance | BindingFlags.Public).SetValue(tool_ToolZ.getLocalPlayer().get_equipment().get_asset(), this.new_range);
		}
	}
}
