using SDG.Unturned;
using System;
using System.Reflection;
using UnityEngine;

namespace CryEye
{
	public class menu_Player : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 10f);

		private bool nightvision_military = false;

		private bool nightvision_civilian = false;

		private bool norain = false;

		private bool nosnow = false;

		private bool prev_night = false;

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
		}

		public void Update()
		{
			bool flag = this.norain;
			if (flag)
			{
				LevelLighting.rainyness = 0;
			}
			bool flag2 = this.nosnow;
			if (flag2)
			{
				LevelLighting.set_snowLevel(0f);
				RenderSettings.set_fogDensity(0f);
				typeof(LevelLighting).GetField("isSnow", BindingFlags.Static | BindingFlags.NonPublic).SetValue(null, false);
				typeof(LevelLighting).GetField("snownyess", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).SetValue(null, 0f);
			}
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_Player, this.window_Main, new GUI.WindowFunction(this.onWindow), "Player Hack Menu", new GUILayoutOption[0]);
			}
			bool flag2 = Event.get_current().get_type() == 7;
			if (flag2)
			{
				bool flag3 = this.nightvision_military;
				if (flag3)
				{
					LevelLighting.vision = 1;
					LevelLighting.updateLighting();
					LevelLighting.updateLocal();
					PlayerLifeUI.updateGrayscale();
					this.prev_night = true;
				}
				else
				{
					bool flag4 = this.nightvision_civilian;
					if (flag4)
					{
						LevelLighting.vision = 2;
						LevelLighting.updateLighting();
						LevelLighting.updateLocal();
						PlayerLifeUI.updateGrayscale();
						this.prev_night = true;
					}
					else
					{
						bool flag5 = this.prev_night;
						if (flag5)
						{
							LevelLighting.vision = 0;
							LevelLighting.updateLighting();
							LevelLighting.updateLocal();
							PlayerLifeUI.updateGrayscale();
							this.prev_night = false;
						}
					}
				}
			}
		}

		public void onWindow(int ID)
		{
			this.nightvision_military = GUILayout.Toggle(this.nightvision_military, "Military Nightvision", new GUILayoutOption[0]);
			this.nightvision_civilian = GUILayout.Toggle(this.nightvision_civilian, "Civilian Nightvision", new GUILayoutOption[0]);
			this.norain = GUILayout.Toggle(this.norain, "No Rain", new GUILayoutOption[0]);
			this.nosnow = GUILayout.Toggle(this.nosnow, "No Snow", new GUILayoutOption[0]);
			bool flag = GUILayout.Button("Drop all items", new GUILayoutOption[0]);
			if (flag)
			{
				for (byte b = 0; b < PlayerInventory.PAGES - 1; b += 1)
				{
					bool flag2 = tool_ToolZ.getLocalPlayer().get_inventory().getItemCount(b) > 0;
					if (flag2)
					{
						for (byte b2 = 0; b2 < tool_ToolZ.getLocalPlayer().get_inventory().getHeight(b); b2 += 1)
						{
							for (byte b3 = 0; b3 < tool_ToolZ.getLocalPlayer().get_inventory().getWidth(b); b3 += 1)
							{
								tool_ToolZ.getLocalPlayer().get_inventory().sendDropItem(b, b3, b2);
							}
						}
					}
				}
			}
			GUILayout.Label("Time: " + LightingManager.get_time(), new GUILayoutOption[0]);
			LightingManager.set_time((uint)Math.Round((double)GUILayout.HorizontalSlider(LightingManager.get_time(), 0f, 3600f, new GUILayoutOption[0])));
			bool flag3 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag3)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}
	}
}
