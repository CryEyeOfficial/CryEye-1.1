using System;
using UnityEngine;

namespace CryEye
{
	public class menu_Fun : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 10f);

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
		}

		public void Update()
		{
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_Fun, this.window_Main, new GUI.WindowFunction(this.onWindow), "MSZ Hack", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			bool flag = GUILayout.Button("Berries (WHY !)", new GUILayoutOption[0]);
			if (flag)
			{
				tool_ToolZ.getLocalPlayer().get_life().askView(20);
			}
			bool flag2 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag2)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}
	}
}
