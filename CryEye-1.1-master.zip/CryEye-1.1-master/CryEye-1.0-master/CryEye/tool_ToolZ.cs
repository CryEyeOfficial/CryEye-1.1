using SDG.Unturned;
using Steamworks;
using System;
using UnityEngine;

namespace CryEye
{
	public class tool_ToolZ
	{
		public static string getTitle()
		{
			return "!ERROR!";
		}

		public static bool noWall(Transform ver, float distance = float.PositiveInfinity)
		{
			return !Physics.Linecast(Camera.get_main().get_transform().get_position(), ver.get_transform().get_position(), RayMasks.DAMAGE_CLIENT);
		}

		public static Player getLocalPlayer()
		{
			return Player.get_player();
		}

		public static float getDistance(Vector3 point)
		{
			return Vector3.Distance(Camera.get_main().get_transform().get_position(), point);
		}

		public static bool getLookingAt(out RaycastHit result, float distance = float.PositiveInfinity)
		{
			return Physics.Raycast(tool_ToolZ.getLocalPlayer().get_look().get_aim().get_position(), tool_ToolZ.getLocalPlayer().get_look().get_aim().get_forward(), ref result, distance);
		}

		public static bool aContains(Array a, object b)
		{
			return Array.IndexOf(a, b) > -1;
		}

		public static ulong getPlayerID(Player p)
		{
			return Array.Find<SteamPlayer>(Provider.get_clients().ToArray(), (SteamPlayer a) => a.get_player() == p).get_playerID().get_steamID().m_SteamID;
		}

		public static SteamPlayer getSteamPlayer(ulong id)
		{
			return Array.Find<SteamPlayer>(Provider.get_clients().ToArray(), (SteamPlayer a) => a.get_playerID().get_steamID().m_SteamID == id);
		}

		public static SteamPlayer getSteamPlayer(string name)
		{
			return Array.Find<SteamPlayer>(Provider.get_clients().ToArray(), (SteamPlayer a) => a.get_playerID().get_playerName() == name || a.get_playerID().nickName == name || a.get_player().get_transform().get_name() == name);
		}

		public static SteamPlayer getSteamPlayer(Player p)
		{
			return Array.Find<SteamPlayer>(Provider.get_clients().ToArray(), (SteamPlayer a) => a.get_player() == p);
		}

		public static SteamPlayer getSteamSemi(string name)
		{
			return Array.Find<SteamPlayer>(Provider.get_clients().ToArray(), (SteamPlayer a) => a.get_player().get_transform().get_name().Contains(name));
		}

		public static SteamPlayer getSteamPlayer(CSteamID id)
		{
			return Array.Find<SteamPlayer>(Provider.get_clients().ToArray(), (SteamPlayer a) => a.get_playerID().get_steamID() == id);
		}

		public static Player getPlayer(string name)
		{
			return Array.Find<SteamPlayer>(Provider.get_clients().ToArray(), (SteamPlayer a) => a.get_playerID().get_playerName() == name || a.get_playerID().nickName == name || a.get_player().get_transform().get_name() == name).get_player();
		}
	}
}
