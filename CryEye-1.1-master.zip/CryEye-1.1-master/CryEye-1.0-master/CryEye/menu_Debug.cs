using SDG.Unturned;
using System;
using UnityEngine;

namespace CryEye
{
	public class menu_Debug : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 10f);

		public InteractableItem[] tmz;

		public Vector2 scroll;

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
		}

		public void Update()
		{
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_Debug, this.window_Main, new GUI.WindowFunction(this.onWindow), "Debug Menu", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			GUILayout.Label(tool_ToolZ.getLocalPlayer().get_look().get_yaw().ToString(), new GUILayoutOption[0]);
			GUILayout.Label(tool_ToolZ.getLocalPlayer().get_look().get_pitch().ToString(), new GUILayoutOption[0]);
			bool flag = GUILayout.Button("Refresh items (May lag)", new GUILayoutOption[0]);
			if (flag)
			{
				this.tmz = Object.FindObjectsOfType<InteractableItem>();
			}
			this.window_Main.set_width(500f);
			this.scroll = GUILayout.BeginScrollView(this.scroll, new GUILayoutOption[0]);
			InteractableItem[] array = this.tmz;
			for (int i = 0; i < array.Length; i++)
			{
				InteractableItem interactableItem = array[i];
				bool flag2 = GUILayout.Button(interactableItem.get_name(), new GUILayoutOption[0]);
				if (flag2)
				{
					interactableItem.GetComponent<Rigidbody>().MovePosition(Player.get_player().get_transform().get_position());
				}
			}
			GUILayout.EndScrollView();
			bool flag3 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag3)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}
	}
}
