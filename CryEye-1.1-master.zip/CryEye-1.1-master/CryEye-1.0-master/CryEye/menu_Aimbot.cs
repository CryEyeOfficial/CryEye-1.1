using SDG.Unturned;
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CryEye
{
	public class menu_Aimbot : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 200f);

		private DateTime lastUpdate;

		private DateTime lastAim;

		private SteamPlayer[] players;

		private Zombie[] zombies;

		private Animal[] animals;

		public bool enabled = false;

		private bool aim_players = true;

		private bool ignore_friends = true;

		private bool ignore_admins = true;

		private bool ignore_walls = true;

		private bool use_gun_distance = true;

		private bool aim_zombies = false;

		private bool aim_animals = false;

		private float distance = 200f;

		private int aim_update = 20;

		private int at_pos = 0;

		private List<AimbotType> at = new List<AimbotType>();

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
			this.at.Add(new AimbotType("Head", "Skull"));
			this.at.Add(new AimbotType("Torso", "Spine"));
		}

		public void Update()
		{
			bool flag = this.enabled;
			if (flag)
			{
				DateTime arg_15_0 = this.lastUpdate;
				bool flag2 = (DateTime.Now - this.lastUpdate).TotalMilliseconds >= 1000.0;
				if (flag2)
				{
					this.update_Information();
					this.lastUpdate = DateTime.Now;
				}
				DateTime arg_5A_0 = this.lastAim;
				bool flag3 = (DateTime.Now - this.lastAim).TotalMilliseconds >= (double)this.aim_update;
				if (flag3)
				{
					this.update_Aim();
					this.lastAim = DateTime.Now;
				}
			}
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_Aimbot, this.window_Main, new GUI.WindowFunction(this.onWindow), "Aimbot Menu", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			this.enabled = GUILayout.Toggle(this.enabled, "Aimbot", new GUILayoutOption[0]);
			this.ignore_walls = GUILayout.Toggle(this.ignore_walls, "Ignore walls", new GUILayoutOption[0]);
			this.use_gun_distance = GUILayout.Toggle(this.use_gun_distance, "Use gun distance", new GUILayoutOption[0]);
			this.aim_players = GUILayout.Toggle(this.aim_players, "Attack Players", new GUILayoutOption[0]);
			this.ignore_friends = GUILayout.Toggle(this.ignore_friends, "Ignore Friends", new GUILayoutOption[0]);
			this.ignore_admins = GUILayout.Toggle(this.ignore_admins, "Ignore Admins", new GUILayoutOption[0]);
			this.aim_zombies = GUILayout.Toggle(this.aim_zombies, "Attack Zombies", new GUILayoutOption[0]);
			this.aim_animals = GUILayout.Toggle(this.aim_animals, "Attack Animals", new GUILayoutOption[0]);
			bool flag = GUILayout.Button("Aim: " + this.at[this.at_pos].name, new GUILayoutOption[0]);
			if (flag)
			{
				this.at_pos++;
				bool flag2 = this.at_pos == this.at.Count;
				if (flag2)
				{
					this.at_pos = 0;
				}
			}
			GUILayout.Label("Distance: " + this.distance, new GUILayoutOption[0]);
			this.distance = GUILayout.HorizontalSlider((float)Math.Round((double)this.distance, 0), 0f, 1000f, new GUILayoutOption[0]);
			GUILayout.Label("Aim Update: " + this.aim_update, new GUILayoutOption[0]);
			this.aim_update = (int)GUILayout.HorizontalSlider((float)Math.Round((double)this.aim_update, 0), 0f, 50f, new GUILayoutOption[0]);
			bool flag3 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag3)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}

		private void update_Aim()
		{
			GameObject gameObject = null;
			bool flag = this.aim_zombies;
			if (flag)
			{
				Zombie nZombie = this.getNZombie();
				bool flag2 = nZombie != null;
				if (flag2)
				{
					bool flag3 = gameObject == null;
					if (flag3)
					{
						gameObject = nZombie.get_gameObject();
					}
					else
					{
						bool flag4 = tool_ToolZ.getDistance(nZombie.get_transform().get_position()) < tool_ToolZ.getDistance(gameObject.get_transform().get_position());
						if (flag4)
						{
							gameObject = nZombie.get_gameObject();
						}
					}
				}
			}
			bool flag5 = this.aim_players;
			if (flag5)
			{
				Player nPlayer = this.getNPlayer();
				bool flag6 = nPlayer != null;
				if (flag6)
				{
					bool flag7 = gameObject == null;
					if (flag7)
					{
						gameObject = nPlayer.get_gameObject();
					}
					else
					{
						bool flag8 = tool_ToolZ.getDistance(nPlayer.get_transform().get_position()) < tool_ToolZ.getDistance(gameObject.get_transform().get_position());
						if (flag8)
						{
							gameObject = nPlayer.get_gameObject();
						}
					}
				}
			}
			bool flag9 = this.aim_animals;
			if (flag9)
			{
				Animal nAnimal = this.getNAnimal();
				bool flag10 = nAnimal != null;
				if (flag10)
				{
					bool flag11 = gameObject == null;
					if (flag11)
					{
						gameObject = nAnimal.get_gameObject();
					}
					else
					{
						bool flag12 = tool_ToolZ.getDistance(nAnimal.get_transform().get_position()) < tool_ToolZ.getDistance(gameObject.get_transform().get_position());
						if (flag12)
						{
							gameObject = nAnimal.get_gameObject();
						}
					}
				}
			}
			bool flag13 = gameObject != null;
			if (flag13)
			{
				this.aim(gameObject);
			}
		}

		private void aim(GameObject obj)
		{
			Vector3 aimPosition = this.getAimPosition(obj.get_transform());
			tool_ToolZ.getLocalPlayer().get_transform().LookAt(aimPosition);
			tool_ToolZ.getLocalPlayer().get_transform().set_eulerAngles(new Vector3(0f, tool_ToolZ.getLocalPlayer().get_transform().get_rotation().get_eulerAngles().y, 0f));
			Camera.get_main().get_transform().LookAt(aimPosition);
			float num = Camera.get_main().get_transform().get_localRotation().get_eulerAngles().x;
			bool flag = num <= 90f && num <= 270f;
			if (flag)
			{
				num = Camera.get_main().get_transform().get_localRotation().get_eulerAngles().x + 90f;
			}
			else
			{
				bool flag2 = num >= 270f && num <= 360f;
				if (flag2)
				{
					num = Camera.get_main().get_transform().get_localRotation().get_eulerAngles().x - 270f;
				}
			}
			tool_ToolZ.getLocalPlayer().get_look().GetType().GetField("_pitch", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(tool_ToolZ.getLocalPlayer().get_look(), num);
			tool_ToolZ.getLocalPlayer().get_look().GetType().GetField("_yaw", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(tool_ToolZ.getLocalPlayer().get_look(), tool_ToolZ.getLocalPlayer().get_transform().get_rotation().get_eulerAngles().y);
		}

		public Vector3 getAimPosition(Transform parent)
		{
			Transform[] componentsInChildren = parent.GetComponentsInChildren<Transform>();
			bool flag = componentsInChildren != null;
			Vector3 result;
			if (flag)
			{
				Transform[] array = componentsInChildren;
				for (int i = 0; i < array.Length; i++)
				{
					Transform transform = array[i];
					bool flag2 = transform.get_name().Trim() == this.at[this.at_pos].dmg;
					if (flag2)
					{
						result = transform.get_position() + new Vector3(0f, 0.4f, 0f);
						return result;
					}
				}
			}
			result = Vector3.get_zero();
			return result;
		}

		private void update_Information()
		{
			this.players = Provider.get_clients().ToArray();
			List<Zombie> list = new List<Zombie>();
			for (int i = 0; i < ZombieManager.get_regions().Length; i++)
			{
				list.AddRange(ZombieManager.get_regions()[i].get_zombies());
			}
			this.zombies = list.ToArray();
			this.animals = AnimalManager.get_animals().ToArray();
		}

		private Animal getNAnimal()
		{
			Animal animal = null;
			for (int i = 0; i < this.animals.Length; i++)
			{
				bool flag = !this.animals[i].isDead && this.correctDist(this.animals[i].get_transform().get_position());
				if (flag)
				{
					bool flag2 = animal == null;
					if (flag2)
					{
						bool flag3 = this.ignore_walls;
						if (flag3)
						{
							animal = this.animals[i];
						}
						else
						{
							bool flag4 = tool_ToolZ.noWall(this.animals[i].get_transform(), float.PositiveInfinity);
							if (flag4)
							{
								animal = this.animals[i];
							}
						}
					}
					else
					{
						bool flag5 = this.ignore_walls;
						if (flag5)
						{
							bool flag6 = tool_ToolZ.getDistance(animal.get_transform().get_position()) > tool_ToolZ.getDistance(this.animals[i].get_transform().get_position());
							if (flag6)
							{
								animal = this.animals[i];
							}
						}
						else
						{
							bool flag7 = tool_ToolZ.noWall(this.animals[i].get_transform(), float.PositiveInfinity);
							if (flag7)
							{
								bool flag8 = tool_ToolZ.getDistance(animal.get_transform().get_position()) > tool_ToolZ.getDistance(this.animals[i].get_transform().get_position());
								if (flag8)
								{
									animal = this.animals[i];
								}
							}
						}
					}
				}
			}
			return animal;
		}

		private Zombie getNZombie()
		{
			Zombie zombie = null;
			for (int i = 0; i < this.zombies.Length; i++)
			{
				bool flag = !this.zombies[i].isDead && this.correctDist(this.zombies[i].get_transform().get_position());
				if (flag)
				{
					bool flag2 = zombie == null;
					if (flag2)
					{
						bool flag3 = this.ignore_walls;
						if (flag3)
						{
							zombie = this.zombies[i];
						}
						else
						{
							bool flag4 = tool_ToolZ.noWall(this.zombies[i].get_transform(), float.PositiveInfinity);
							if (flag4)
							{
								zombie = this.zombies[i];
							}
						}
					}
					else
					{
						bool flag5 = this.ignore_walls;
						if (flag5)
						{
							bool flag6 = tool_ToolZ.getDistance(zombie.get_transform().get_position()) > tool_ToolZ.getDistance(this.zombies[i].get_transform().get_position());
							if (flag6)
							{
								zombie = this.zombies[i];
							}
						}
						else
						{
							bool flag7 = tool_ToolZ.noWall(this.zombies[i].get_transform(), float.PositiveInfinity);
							if (flag7)
							{
								bool flag8 = tool_ToolZ.getDistance(zombie.get_transform().get_position()) > tool_ToolZ.getDistance(this.zombies[i].get_transform().get_position());
								if (flag8)
								{
									zombie = this.zombies[i];
								}
							}
						}
					}
				}
			}
			return zombie;
		}

		private bool canAttack(SteamPlayer p)
		{
			bool flag = !ctrl_Connector.skid.isWhitelist(p.get_playerID().get_steamID().m_SteamID);
			bool result;
			if (flag)
			{
				bool flag2 = this.ignore_friends;
				if (flag2)
				{
					bool flag3 = !ctrl_Connector.hack_Friends.isFriend(p);
					if (flag3)
					{
						bool flag4 = this.ignore_admins;
						if (flag4)
						{
							bool flag5 = !p.get_isAdmin();
							result = flag5;
						}
						else
						{
							result = true;
						}
					}
					else
					{
						result = false;
					}
				}
				else
				{
					result = true;
				}
			}
			else
			{
				result = false;
			}
			return result;
		}

		private bool correctDist(Vector3 pos)
		{
			bool flag = this.use_gun_distance;
			bool result;
			if (flag)
			{
				bool flag2 = tool_ToolZ.getDistance(pos) <= ((ItemWeaponAsset)tool_ToolZ.getLocalPlayer().get_equipment().get_asset()).range;
				result = flag2;
			}
			else
			{
				bool flag3 = tool_ToolZ.getDistance(pos) <= this.distance;
				result = flag3;
			}
			return result;
		}

		private Player getNPlayer()
		{
			Player player = null;
			for (int i = 0; i < this.players.Length; i++)
			{
				bool flag = this.players[i].get_playerID().get_steamID() != Provider.get_client() && this.players[i].get_player().get_life() != null && !this.players[i].get_player().get_life().get_isDead() && this.canAttack(this.players[i]) && this.correctDist(this.players[i].get_player().get_transform().get_position());
				if (flag)
				{
					bool flag2 = player == null;
					if (flag2)
					{
						bool flag3 = this.ignore_walls;
						if (flag3)
						{
							player = this.players[i].get_player();
						}
						else
						{
							bool flag4 = tool_ToolZ.noWall(this.players[i].get_player().get_transform(), float.PositiveInfinity);
							if (flag4)
							{
								player = this.players[i].get_player();
							}
						}
					}
					else
					{
						bool flag5 = this.ignore_walls;
						if (flag5)
						{
							bool flag6 = tool_ToolZ.getDistance(player.get_transform().get_position()) > tool_ToolZ.getDistance(this.players[i].get_player().get_transform().get_position());
							if (flag6)
							{
								player = this.players[i].get_player();
							}
						}
						else
						{
							bool flag7 = tool_ToolZ.noWall(this.players[i].get_player().get_transform(), float.PositiveInfinity);
							if (flag7)
							{
								bool flag8 = tool_ToolZ.getDistance(player.get_transform().get_position()) > tool_ToolZ.getDistance(this.players[i].get_player().get_transform().get_position());
								if (flag8)
								{
									player = this.players[i].get_player();
								}
							}
						}
					}
				}
			}
			return player;
		}
	}
}
