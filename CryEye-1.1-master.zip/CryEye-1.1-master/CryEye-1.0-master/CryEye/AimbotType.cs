using System;

namespace CryEye
{
	public class AimbotType
	{
		public string name;

		public string dmg;

		public AimbotType(string name, string dmg)
		{
			this.name = name;
			this.dmg = dmg;
		}
	}
}
