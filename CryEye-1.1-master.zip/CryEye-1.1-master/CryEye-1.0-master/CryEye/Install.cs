using System;
using UnityEngine;

namespace CryEye
{
	public class Install : MonoBehaviour
	{
		public static GameObject hook_obj = null;

		private static CryEye instance = null;

		public static void Launch()
		{
			try
			{
				Install.hook_obj = new GameObject();
				Install.instance = Install.hook_obj.AddComponent<CryEye>();
				Object.DontDestroyOnLoad(Install.instance);
			}
			catch (Exception ex)
			{
				Debug.LogWarning("----- CRASH -----");
				Debug.LogException(ex);
				Debug.LogWarning("------ END ------");
			}
		}
	}
}
