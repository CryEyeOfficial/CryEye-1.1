using System;
using UnityEngine;

namespace CryEye
{
	public class menu_Main : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(40f, 40f, 200f, 40f);

		private Vector2 scroll;

		private DateTime lastCheck;

		public bool banned_hack = false;

		public bool banned_game = false;

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
		}

		public void Update()
		{
			ctrl_Connector.allow = true;
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_Main, this.window_Main, new GUI.WindowFunction(this.onWindow), "CryEye 1.1", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			bool flag = GUILayout.Button("Player Hacks", new GUILayoutOption[0]);
			if (flag)
			{
				ctrl_Connector.hack_Player.toggleOn();
			}
			bool flag2 = GUILayout.Button("Aimbot", new GUILayoutOption[0]);
			if (flag2)
			{
				ctrl_Connector.hack_Aimbot.toggleOn();
			}
			bool flag3 = GUILayout.Button("Cry Eye ESP", new GUILayoutOption[0]);
			if (flag3)
			{
				ctrl_Connector.hack_ESP.toggleOn();
			}
			bool flag4 = GUILayout.Button("Aimlock/Triggerbot", new GUILayoutOption[0]);
			if (flag4)
			{
				ctrl_Connector.hack_AimlockTriggerbot.toggleOn();
			}
			bool flag5 = GUILayout.Button("Weapon Hacks", new GUILayoutOption[0]);
			if (flag5)
			{
				ctrl_Connector.hack_Weapons.toggleOn();
			}
			bool flag6 = GUILayout.Button("Vehicle Hacks", new GUILayoutOption[0]);
			if (flag6)
			{
				ctrl_Connector.hack_Vehicle.toggleOn();
			}
			bool flag7 = GUILayout.Button("Auto Item Pickup", new GUILayoutOption[0]);
			if (flag7)
			{
				ctrl_Connector.hack_ItemPickup.toggleOn();
			}
			bool flag8 = GUILayout.Button("Item Selection", new GUILayoutOption[0]);
			if (flag8)
			{
				ctrl_Connector.hack_ItemSelection.toggleOn();
			}
			bool flag9 = GUILayout.Button("Add Friend", new GUILayoutOption[0]);
			if (flag9)
			{
				ctrl_Connector.hack_Friends.sw = true;
				ctrl_Connector.hack_Friends.toggleOn();
			}
			bool flag10 = GUILayout.Button("Remove Friend", new GUILayoutOption[0]);
			if (flag10)
			{
				ctrl_Connector.hack_Friends.sw = false;
				ctrl_Connector.hack_Friends.toggleOn();
			}
			bool flag11 = GUILayout.Button("Keybinds", new GUILayoutOption[0]);
			if (flag11)
			{
				ctrl_Connector.hack_Keybind.toggleOn();
			}
			bool flag12 = GUILayout.Button("Settings", new GUILayoutOption[0]);
			if (flag12)
			{
				ctrl_Connector.hack_Settings.toggleOn();
			}
			bool flag13 = GUILayout.Button("Cry Eye Specials", new GUILayoutOption[0]);
			if (flag13)
			{
				ctrl_Connector.hack_Fun.toggleOn();
                  }
                  bool flag14 = GUILayout
Button("License",new GUILayoutOption[0]);
                         if (flag14)
                         {
                                  ctrl_Connector.hack
_System.Diagnostics.Process.Start("https://github.com/AtiLion/MSZ-Reborn/blob/master/LICENSE");
                          }
                          bool flag15 = GUILayout
Button("Discord",new GUILayoutOption[0]);        
                         if (flag15)
                         {
                                   ctrl_Connector.hack
_System.Diagnostics.Process.Start("https://discord.gg/AwYxMUW");
 			}
			GUI.DragWindow();
		}
	}
}
