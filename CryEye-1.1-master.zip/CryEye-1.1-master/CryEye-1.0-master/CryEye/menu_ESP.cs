using SDG.Unturned;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace CryEye
{
	public class menu_ESP : MonoBehaviour
	{
		private KeyCode key;

		private bool isOn;

		private lib_ESP lib_ESP;

		private Rect window_Main = new Rect(5f, 5f, 200f, 10f);

		public bool enabled = false;

		public float distance = 1000f;

		public int ref_Rate = 100;

		public bool show_Players = true;

		public bool players_Weapon = false;

		public bool players_Name = false;

		public bool show_Zombies = false;

		public bool show_Items = false;

		public bool items_Name = false;

		public bool show_Animals = false;

		public bool show_Cars = false;

		public bool cars_Name = false;

		public bool show_Storages = false;

		public bool get_Distance = false;

		public SteamPlayer[] players;

		public Zombie[] zombies;

		public Animal[] animals;

		public InteractableVehicle[] vehicles;

		public InteractableItem[] items;

		public InteractableStorage[] storages;

		private DateTime lastTime;

		public List<HighlightedObject> ho = new List<HighlightedObject>();

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
			this.lib_ESP = new lib_ESP(this);
		}

		public void Update()
		{
			bool flag = this.enabled;
			if (flag)
			{
				DateTime arg_15_0 = this.lastTime;
				bool flag2 = (DateTime.Now - this.lastTime).TotalMilliseconds >= 1500.0;
				if (flag2)
				{
					this.players = Provider.get_clients().ToArray();
					List<Zombie> list = new List<Zombie>();
					for (int i = 0; i < ZombieManager.get_regions().Length; i++)
					{
						list.AddRange(ZombieManager.get_regions()[i].get_zombies());
					}
					this.zombies = list.ToArray();
					this.animals = AnimalManager.get_animals().ToArray();
					this.vehicles = VehicleManager.get_vehicles().ToArray();
					this.items = (Object.FindObjectsOfType(typeof(InteractableItem)) as InteractableItem[]);
					this.storages = (Object.FindObjectsOfType(typeof(InteractableStorage)) as InteractableStorage[]);
					this.lastTime = DateTime.Now;
				}
			}
			this.lib_ESP.update();
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_ESP, this.window_Main, new GUI.WindowFunction(this.onWindow), "ESP Menu", new GUILayoutOption[0]);
			}
			this.lib_ESP.gui();
		}

		public void onWindow(int ID)
		{
			this.enabled = GUILayout.Toggle(this.enabled, "Enabled ESP", new GUILayoutOption[0]);
			this.show_Players = GUILayout.Toggle(this.show_Players, "Show Players", new GUILayoutOption[0]);
			this.players_Name = GUILayout.Toggle(this.players_Name, "Get Player Names", new GUILayoutOption[0]);
			this.show_Zombies = GUILayout.Toggle(this.show_Zombies, "Show Zombies", new GUILayoutOption[0]);
			this.show_Animals = GUILayout.Toggle(this.show_Animals, "Show Animals", new GUILayoutOption[0]);
			this.show_Cars = GUILayout.Toggle(this.show_Cars, "Show Vehicles", new GUILayoutOption[0]);
			this.cars_Name = GUILayout.Toggle(this.cars_Name, "Get Vehicle Names", new GUILayoutOption[0]);
			this.show_Items = GUILayout.Toggle(this.show_Items, "Show Items", new GUILayoutOption[0]);
			this.items_Name = GUILayout.Toggle(this.items_Name, "Get Item Names", new GUILayoutOption[0]);
			this.show_Storages = GUILayout.Toggle(this.show_Storages, "Show Storages", new GUILayoutOption[0]);
			this.get_Distance = GUILayout.Toggle(this.get_Distance, "Get Distance", new GUILayoutOption[0]);
			GUILayout.Label("Distance: " + this.distance, new GUILayoutOption[0]);
			this.distance = GUILayout.HorizontalSlider((float)Math.Round((double)this.distance, 0), 0f, 10000f, new GUILayoutOption[0]);
			GUILayout.Label("Refresh Rate(reverse lag): " + this.ref_Rate, new GUILayoutOption[0]);
			this.ref_Rate = (int)GUILayout.HorizontalSlider((float)Math.Round((double)this.ref_Rate, 0), 10f, 1000f, new GUILayoutOption[0]);
			bool flag = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}
	}
}
