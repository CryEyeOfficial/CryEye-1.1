using System;
using UnityEngine;

namespace CryEye
{
	internal class CryEye MonoBehaviour
	{
		private static GameObject hookObj = null;

		private Camera cam = Camera.get_main();

		private ctrl_Connector con = new ctrl_Connector();

		public void Start()
		{
		}

		public void Update()
		{
			this.con.onUpdate();
		}

		public void OnGUI()
		{
			this.con.onGUI();
		}
	}
}
