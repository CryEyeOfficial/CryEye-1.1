using HighlightingSystem;
using SDG.Unturned;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace CryEye
{
	public class lib_ESP : MonoBehaviour
	{
		[CompilerGenerated]
		[Serializable]
		private sealed class <>c
		{
			public static readonly lib_ESP.<>c <>9 = new lib_ESP.<>c();

			public static Predicate<HighlightedObject> <>9__15_1;

			public static Predicate<HighlightedObject> <>9__16_1;

			public static Predicate<HighlightedObject> <>9__17_1;

			public static Predicate<HighlightedObject> <>9__18_1;

			public static Predicate<HighlightedObject> <>9__19_1;

			public static Predicate<HighlightedObject> <>9__21_2;

			internal bool <update_Zombie>b__15_1(HighlightedObject a)
			{
				return a.dType == 1;
			}

			internal bool <update_Player>b__16_1(HighlightedObject a)
			{
				return a.dType == 0;
			}

			internal bool <update_Animals>b__17_1(HighlightedObject a)
			{
				return a.dType == 4;
			}

			internal bool <update_Cars>b__18_1(HighlightedObject a)
			{
				return a.dType == 2;
			}

			internal bool <update_Storages>b__19_1(HighlightedObject a)
			{
				return a.dType == 5;
			}

			internal bool <update_Items>b__21_2(HighlightedObject a)
			{
				return a.dType == 3;
			}
		}

		private menu_ESP esp;

		private menu_ItemSelection itemsel;

		private DateTime lastTime;

		private DateTime lastRendTime;

		private DateTime lastFilterTime;

		private bool wasPlayer = false;

		public bool wasZombie = false;

		public bool wasItem = false;

		public bool wasAnimal = false;

		public bool wasCar = false;

		public bool wasStorage = false;

		private List<InteractableItem> itemFilter = new List<InteractableItem>();

		private List<NameDisplay> renderDisplay = new List<NameDisplay>();

		public lib_ESP(menu_ESP esp)
		{
			this.esp = esp;
			this.itemsel = ctrl_Connector.hack_ItemSelection;
		}

		private void DrawLabel(Vector3 point, string label, float fromY = 0f)
		{
			GUI.Label(new Rect(point.x, point.y + fromY, 500f, 24f), label);
		}

		private void update_Zombie()
		{
			bool show_Zombies = this.esp.show_Zombies;
			if (show_Zombies)
			{
				for (int i = 0; i < this.esp.zombies.Length; i++)
				{
					bool flag = this.esp.zombies[i] != null && this.esp.zombies[i].get_gameObject() != null;
					if (flag)
					{
						GameObject gameObject = this.esp.zombies[i].get_gameObject();
						bool flag2 = tool_ToolZ.getDistance(gameObject.get_transform().get_position()) <= this.esp.distance;
						if (flag2)
						{
							Highlighter highlighter = gameObject.GetComponent<Highlighter>();
							bool flag3 = highlighter == null;
							if (flag3)
							{
								highlighter = gameObject.AddComponent<Highlighter>();
								highlighter.OccluderOn();
								highlighter.SeeThroughOn();
								highlighter.ConstantOn(ctrl_Settings.esp_Zombie_color);
								this.esp.ho.Add(new HighlightedObject(1, gameObject, highlighter));
							}
						}
					}
				}
				try
				{
					HighlightedObject[] array = Array.FindAll<HighlightedObject>(this.esp.ho.ToArray(), (HighlightedObject a) => a.dType == 1 && a != null && a.h != null && a.go != null && a.go.get_transform() != null && tool_ToolZ.getDistance(a.go.get_transform().get_position()) > this.esp.distance);
					bool flag4 = array.Length != 0;
					if (flag4)
					{
						for (int j = 0; j < array.Length; j++)
						{
							Object.Destroy(array[j].h);
							this.esp.ho.Remove(array[j]);
						}
					}
					this.wasZombie = true;
				}
				catch (Exception ex)
				{
					Debug.LogWarning("----------------- ERROR ----------------");
					Debug.LogException(ex);
					Debug.LogWarning("----------------- ERROR ----------------");
				}
			}
			else
			{
				bool flag5 = this.wasZombie && !this.esp.show_Zombies;
				if (flag5)
				{
					HighlightedObject[] arg_1FF_0 = this.esp.ho.ToArray();
					Predicate<HighlightedObject> arg_1FF_1;
					if ((arg_1FF_1 = lib_ESP.<>c.<>9__15_1) == null)
					{
						arg_1FF_1 = (lib_ESP.<>c.<>9__15_1 = new Predicate<HighlightedObject>(lib_ESP.<>c.<>9.<update_Zombie>b__15_1));
					}
					HighlightedObject[] array2 = Array.FindAll<HighlightedObject>(arg_1FF_0, arg_1FF_1);
					for (int k = 0; k < array2.Length; k++)
					{
						bool flag6 = array2[k] != null && array2[k].h != null;
						if (flag6)
						{
							Object.Destroy(array2[k].h);
							this.esp.ho.Remove(array2[k]);
						}
					}
					this.wasZombie = false;
				}
			}
		}

		private void update_Player()
		{
			bool show_Players = this.esp.show_Players;
			if (show_Players)
			{
				for (int i = 0; i < this.esp.players.Length; i++)
				{
					bool flag = this.esp.players[i] != null && this.esp.players[i].get_player() != null && this.esp.players[i].get_player().get_gameObject() != null;
					if (flag)
					{
						bool flag2 = this.esp.players[i].get_player() != tool_ToolZ.getLocalPlayer();
						if (flag2)
						{
							GameObject gameObject = this.esp.players[i].get_player().get_gameObject();
							bool flag3 = tool_ToolZ.getDistance(gameObject.get_transform().get_position()) <= this.esp.distance;
							if (flag3)
							{
								Highlighter highlighter = gameObject.GetComponent<Highlighter>();
								bool flag4 = highlighter == null;
								if (flag4)
								{
									highlighter = gameObject.AddComponent<Highlighter>();
									highlighter.OccluderOn();
									highlighter.SeeThroughOn();
									bool flag5 = ctrl_Connector.hack_Friends.isFriend(this.esp.players[i]);
									if (flag5)
									{
										highlighter.ConstantOn(ctrl_Settings.esp_Friend_color);
									}
									else
									{
										highlighter.ConstantOn(ctrl_Settings.esp_Player_color);
									}
									this.esp.ho.Add(new HighlightedObject(0, gameObject, highlighter));
								}
							}
						}
					}
				}
				try
				{
					HighlightedObject[] array = Array.FindAll<HighlightedObject>(this.esp.ho.ToArray(), (HighlightedObject a) => a.dType == 0 && a != null && a.h != null && a.go != null && a.go.get_transform() != null && tool_ToolZ.getDistance(a.go.get_transform().get_position()) > this.esp.distance);
					bool flag6 = array.Length != 0;
					if (flag6)
					{
						for (int j = 0; j < array.Length; j++)
						{
							Object.Destroy(array[j].h);
							this.esp.ho.Remove(array[j]);
						}
					}
					this.wasPlayer = true;
				}
				catch (Exception ex)
				{
					Debug.LogWarning("----------------- ERROR ----------------");
					Debug.LogException(ex);
					Debug.LogWarning("----------------- ERROR ----------------");
				}
			}
			else
			{
				bool flag7 = this.wasPlayer && !this.esp.show_Players;
				if (flag7)
				{
					HighlightedObject[] arg_27A_0 = this.esp.ho.ToArray();
					Predicate<HighlightedObject> arg_27A_1;
					if ((arg_27A_1 = lib_ESP.<>c.<>9__16_1) == null)
					{
						arg_27A_1 = (lib_ESP.<>c.<>9__16_1 = new Predicate<HighlightedObject>(lib_ESP.<>c.<>9.<update_Player>b__16_1));
					}
					HighlightedObject[] array2 = Array.FindAll<HighlightedObject>(arg_27A_0, arg_27A_1);
					for (int k = 0; k < array2.Length; k++)
					{
						bool flag8 = array2[k] != null && array2[k].h != null;
						if (flag8)
						{
							Object.Destroy(array2[k].h);
							this.esp.ho.Remove(array2[k]);
						}
					}
					this.wasPlayer = false;
				}
			}
		}

		private void update_Animals()
		{
			bool show_Animals = this.esp.show_Animals;
			if (show_Animals)
			{
				for (int i = 0; i < this.esp.animals.Length; i++)
				{
					bool flag = this.esp.animals[i] != null && this.esp.animals[i].get_gameObject() != null;
					if (flag)
					{
						GameObject gameObject = this.esp.animals[i].get_gameObject();
						bool flag2 = tool_ToolZ.getDistance(gameObject.get_transform().get_position()) <= this.esp.distance;
						if (flag2)
						{
							Highlighter highlighter = gameObject.GetComponent<Highlighter>();
							bool flag3 = highlighter == null;
							if (flag3)
							{
								highlighter = gameObject.AddComponent<Highlighter>();
								highlighter.OccluderOn();
								highlighter.SeeThroughOn();
								highlighter.ConstantOn(ctrl_Settings.esp_Animal_color);
								this.esp.ho.Add(new HighlightedObject(4, gameObject, highlighter));
							}
						}
					}
				}
				try
				{
					HighlightedObject[] array = Array.FindAll<HighlightedObject>(this.esp.ho.ToArray(), (HighlightedObject a) => a.dType == 4 && a != null && a.h != null && a.go != null && a.go.get_transform() != null && tool_ToolZ.getDistance(a.go.get_transform().get_position()) > this.esp.distance);
					bool flag4 = array.Length != 0;
					if (flag4)
					{
						for (int j = 0; j < array.Length; j++)
						{
							Object.Destroy(array[j].h);
							this.esp.ho.Remove(array[j]);
						}
					}
					this.wasAnimal = true;
				}
				catch (Exception ex)
				{
					Debug.LogWarning("----------------- ERROR ----------------");
					Debug.LogException(ex);
					Debug.LogWarning("----------------- ERROR ----------------");
				}
			}
			else
			{
				bool flag5 = this.wasAnimal && !this.esp.show_Animals;
				if (flag5)
				{
					HighlightedObject[] arg_1FF_0 = this.esp.ho.ToArray();
					Predicate<HighlightedObject> arg_1FF_1;
					if ((arg_1FF_1 = lib_ESP.<>c.<>9__17_1) == null)
					{
						arg_1FF_1 = (lib_ESP.<>c.<>9__17_1 = new Predicate<HighlightedObject>(lib_ESP.<>c.<>9.<update_Animals>b__17_1));
					}
					HighlightedObject[] array2 = Array.FindAll<HighlightedObject>(arg_1FF_0, arg_1FF_1);
					for (int k = 0; k < array2.Length; k++)
					{
						bool flag6 = array2[k] != null && array2[k].h != null;
						if (flag6)
						{
							Object.Destroy(array2[k].h);
							this.esp.ho.Remove(array2[k]);
						}
					}
					this.wasAnimal = false;
				}
			}
		}

		private void update_Cars()
		{
			bool show_Cars = this.esp.show_Cars;
			if (show_Cars)
			{
				for (int i = 0; i < this.esp.vehicles.Length; i++)
				{
					bool flag = this.esp.vehicles[i] != null && this.esp.vehicles[i].get_gameObject() != null && this.esp.vehicles[i].health > 0;
					if (flag)
					{
						GameObject gameObject = this.esp.vehicles[i].get_gameObject();
						bool flag2 = tool_ToolZ.getDistance(gameObject.get_transform().get_position()) <= this.esp.distance;
						if (flag2)
						{
							Highlighter highlighter = gameObject.GetComponent<Highlighter>();
							bool flag3 = highlighter == null;
							if (flag3)
							{
								highlighter = gameObject.AddComponent<Highlighter>();
								highlighter.OccluderOn();
								highlighter.SeeThroughOn();
								highlighter.ConstantOn(ctrl_Settings.esp_Car_color);
								this.esp.ho.Add(new HighlightedObject(2, gameObject, highlighter));
							}
						}
					}
				}
				try
				{
					HighlightedObject[] array = Array.FindAll<HighlightedObject>(this.esp.ho.ToArray(), (HighlightedObject a) => a.dType == 2 && a != null && a.h != null && a.go != null && a.go.get_transform() != null && tool_ToolZ.getDistance(a.go.get_transform().get_position()) > this.esp.distance && a.go.GetComponent<InteractableVehicle>() != null && a.go.GetComponent<InteractableVehicle>().health <= 0);
					bool flag4 = array.Length != 0;
					if (flag4)
					{
						for (int j = 0; j < array.Length; j++)
						{
							Object.Destroy(array[j].h);
							this.esp.ho.Remove(array[j]);
						}
					}
					this.wasCar = true;
				}
				catch (Exception ex)
				{
					Debug.LogWarning("----------------- ERROR ----------------");
					Debug.LogException(ex);
					Debug.LogWarning("----------------- ERROR ----------------");
				}
			}
			else
			{
				bool flag5 = this.wasCar && !this.esp.show_Cars;
				if (flag5)
				{
					HighlightedObject[] arg_216_0 = this.esp.ho.ToArray();
					Predicate<HighlightedObject> arg_216_1;
					if ((arg_216_1 = lib_ESP.<>c.<>9__18_1) == null)
					{
						arg_216_1 = (lib_ESP.<>c.<>9__18_1 = new Predicate<HighlightedObject>(lib_ESP.<>c.<>9.<update_Cars>b__18_1));
					}
					HighlightedObject[] array2 = Array.FindAll<HighlightedObject>(arg_216_0, arg_216_1);
					for (int k = 0; k < array2.Length; k++)
					{
						bool flag6 = array2[k] != null && array2[k].h != null;
						if (flag6)
						{
							Object.Destroy(array2[k].h);
							this.esp.ho.Remove(array2[k]);
						}
					}
					this.wasCar = false;
				}
			}
		}

		private void update_Storages()
		{
			bool show_Storages = this.esp.show_Storages;
			if (show_Storages)
			{
				for (int i = 0; i < this.esp.storages.Length; i++)
				{
					bool flag = this.esp.storages[i] != null && this.esp.storages[i].get_gameObject() != null;
					if (flag)
					{
						GameObject gameObject = this.esp.storages[i].get_gameObject();
						bool flag2 = tool_ToolZ.getDistance(gameObject.get_transform().get_position()) <= this.esp.distance;
						if (flag2)
						{
							Highlighter highlighter = gameObject.GetComponent<Highlighter>();
							bool flag3 = highlighter == null;
							if (flag3)
							{
								highlighter = gameObject.AddComponent<Highlighter>();
								highlighter.OccluderOn();
								highlighter.SeeThroughOn();
								highlighter.ConstantOn(ctrl_Settings.esp_Storage_color);
								this.esp.ho.Add(new HighlightedObject(5, gameObject, highlighter));
							}
						}
					}
				}
				try
				{
					HighlightedObject[] array = Array.FindAll<HighlightedObject>(this.esp.ho.ToArray(), (HighlightedObject a) => a.dType == 5 && a != null && a.h != null && a.go != null && a.go.get_transform() != null && tool_ToolZ.getDistance(a.go.get_transform().get_position()) > this.esp.distance);
					bool flag4 = array.Length != 0;
					if (flag4)
					{
						for (int j = 0; j < array.Length; j++)
						{
							Object.Destroy(array[j].h);
							this.esp.ho.Remove(array[j]);
						}
					}
					this.wasStorage = true;
				}
				catch (Exception ex)
				{
					Debug.LogWarning("----------------- ERROR ----------------");
					Debug.LogException(ex);
					Debug.LogWarning("----------------- ERROR ----------------");
				}
			}
			else
			{
				bool flag5 = this.wasStorage && !this.esp.show_Storages;
				if (flag5)
				{
					HighlightedObject[] arg_1FF_0 = this.esp.ho.ToArray();
					Predicate<HighlightedObject> arg_1FF_1;
					if ((arg_1FF_1 = lib_ESP.<>c.<>9__19_1) == null)
					{
						arg_1FF_1 = (lib_ESP.<>c.<>9__19_1 = new Predicate<HighlightedObject>(lib_ESP.<>c.<>9.<update_Storages>b__19_1));
					}
					HighlightedObject[] array2 = Array.FindAll<HighlightedObject>(arg_1FF_0, arg_1FF_1);
					for (int k = 0; k < array2.Length; k++)
					{
						bool flag6 = array2[k] != null && array2[k].h != null;
						if (flag6)
						{
							Object.Destroy(array2[k].h);
							this.esp.ho.Remove(array2[k]);
						}
					}
					this.wasStorage = false;
				}
			}
		}

		private void update_ItemFilter()
		{
			bool show_Items = this.esp.show_Items;
			if (show_Items)
			{
				this.itemFilter.Clear();
				bool flag = this.itemsel.guns || this.itemsel.melee || this.itemsel.ammo || this.itemsel.attachments || this.itemsel.throwable || this.itemsel.clothing || this.itemsel.bags || this.itemsel.medical || this.itemsel.foodnwater || this.itemsel.custom;
				if (flag)
				{
					for (int i = 0; i < this.esp.items.Length; i++)
					{
						bool flag2 = this.esp.items[i] != null && this.esp.items[i].asset != null && this.esp.items[i].get_gameObject() != null;
						if (flag2)
						{
							bool flag3 = this.itemsel.guns && this.esp.items[i].asset is ItemGunAsset;
							if (flag3)
							{
								this.itemFilter.Add(this.esp.items[i]);
							}
							else
							{
								bool flag4 = this.itemsel.melee && this.esp.items[i].asset is ItemMeleeAsset;
								if (flag4)
								{
									this.itemFilter.Add(this.esp.items[i]);
								}
								else
								{
									bool flag5 = this.itemsel.ammo && this.esp.items[i].asset is ItemMagazineAsset;
									if (flag5)
									{
										this.itemFilter.Add(this.esp.items[i]);
									}
									else
									{
										bool flag6 = this.itemsel.attachments && (this.esp.items[i].asset is ItemBarrelAsset || this.esp.items[i].asset is ItemCaliberAsset || this.esp.items[i].asset is ItemGripAsset || this.esp.items[i].asset is ItemOpticAsset || this.esp.items[i].asset is ItemTacticalAsset);
										if (flag6)
										{
											this.itemFilter.Add(this.esp.items[i]);
										}
										else
										{
											bool flag7 = this.itemsel.throwable && this.esp.items[i].asset is ItemThrowableAsset;
											if (flag7)
											{
												this.itemFilter.Add(this.esp.items[i]);
											}
											else
											{
												bool flag8 = this.itemsel.clothing && (this.esp.items[i].asset is ItemHatAsset || this.esp.items[i].asset is ItemGlassesAsset || this.esp.items[i].asset is ItemMaskAsset || this.esp.items[i].asset is ItemShirtAsset || this.esp.items[i].asset is ItemPantsAsset || this.esp.items[i].asset is ItemClothingAsset);
												if (flag8)
												{
													this.itemFilter.Add(this.esp.items[i]);
												}
												else
												{
													bool flag9 = this.itemsel.bags && this.esp.items[i].asset is ItemBackpackAsset;
													if (flag9)
													{
														this.itemFilter.Add(this.esp.items[i]);
													}
													else
													{
														bool flag10 = this.itemsel.medical && this.esp.items[i].asset is ItemMedicalAsset;
														if (flag10)
														{
															this.itemFilter.Add(this.esp.items[i]);
														}
														else
														{
															bool flag11 = this.itemsel.foodnwater && this.esp.items[i].asset is ItemConsumeableAsset;
															if (flag11)
															{
																this.itemFilter.Add(this.esp.items[i]);
															}
															else
															{
																bool flag12 = this.itemsel.custom && ctrl_Connector.hack_CustomItem.existsCustomItem(this.esp.items[i].item.get_id());
																if (flag12)
																{
																	this.itemFilter.Add(this.esp.items[i]);
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		private void update_Items()
		{
			bool show_Items = this.esp.show_Items;
			if (show_Items)
			{
				for (int i = 0; i < this.itemFilter.Count; i++)
				{
					bool flag = this.itemFilter[i] != null && this.itemFilter[i].get_gameObject() != null && this.itemFilter[i].asset != null;
					if (flag)
					{
						GameObject gameObject = this.itemFilter[i].get_gameObject();
						bool flag2 = tool_ToolZ.getDistance(gameObject.get_transform().get_position()) <= this.esp.distance;
						if (flag2)
						{
							Highlighter highlighter = gameObject.GetComponent<Highlighter>();
							bool flag3 = highlighter == null;
							if (flag3)
							{
								highlighter = gameObject.AddComponent<Highlighter>();
								highlighter.OccluderOn();
								highlighter.SeeThroughOn();
								highlighter.ConstantOn(ctrl_Settings.esp_Item_color);
								this.esp.ho.Add(new HighlightedObject(3, gameObject, highlighter));
							}
						}
					}
				}
				try
				{
					HighlightedObject[] array = Array.FindAll<HighlightedObject>(this.esp.ho.ToArray(), (HighlightedObject a) => (a.dType == 3 && a != null && a.h != null && a.go != null && a.go.get_transform() != null && tool_ToolZ.getDistance(a.go.get_transform().get_position()) > this.esp.distance) || (!Array.Exists<InteractableItem>(this.itemFilter.ToArray(), (InteractableItem b) => b.get_gameObject() == a.go) && a.dType == 3));
					bool flag4 = array.Length != 0;
					if (flag4)
					{
						for (int j = 0; j < array.Length; j++)
						{
							Object.Destroy(array[j].h);
							this.esp.ho.Remove(array[j]);
						}
					}
					this.wasItem = true;
				}
				catch (Exception ex)
				{
					Debug.LogWarning("----------------- ERROR ----------------");
					Debug.LogException(ex);
					Debug.LogWarning("----------------- ERROR ----------------");
				}
			}
			else
			{
				bool flag5 = this.wasItem && !this.esp.show_Items;
				if (flag5)
				{
					HighlightedObject[] arg_210_0 = this.esp.ho.ToArray();
					Predicate<HighlightedObject> arg_210_1;
					if ((arg_210_1 = lib_ESP.<>c.<>9__21_2) == null)
					{
						arg_210_1 = (lib_ESP.<>c.<>9__21_2 = new Predicate<HighlightedObject>(lib_ESP.<>c.<>9.<update_Items>b__21_2));
					}
					HighlightedObject[] array2 = Array.FindAll<HighlightedObject>(arg_210_0, arg_210_1);
					for (int k = 0; k < array2.Length; k++)
					{
						bool flag6 = array2[k] != null && array2[k].h != null;
						if (flag6)
						{
							Object.Destroy(array2[k].h);
							this.esp.ho.Remove(array2[k]);
						}
					}
					this.wasItem = false;
				}
			}
		}

		public void update_Name_Display()
		{
			this.renderDisplay.Clear();
			bool players_Name = this.esp.players_Name;
			if (players_Name)
			{
				for (int i = 0; i < this.esp.players.Length; i++)
				{
					bool flag = this.esp.players[i] != null && this.esp.players[i].get_player() != null && this.esp.players[i].get_player().get_gameObject() != null && this.esp.players[i].get_player() != tool_ToolZ.getLocalPlayer();
					if (flag)
					{
						GameObject gameObject = this.esp.players[i].get_player().get_gameObject();
						float num = (float)Math.Round((double)tool_ToolZ.getDistance(gameObject.get_transform().get_position()), 0);
						bool flag2 = num <= this.esp.distance;
						if (flag2)
						{
							Vector3 vector = Camera.get_main().WorldToScreenPoint(gameObject.get_transform().get_position());
							bool flag3 = vector.z > 0f && vector.y < (float)(Screen.get_width() - 2);
							if (flag3)
							{
								vector.y = (float)Screen.get_height() - (vector.y + 1f) - 12f;
								vector.x -= 64f;
								this.renderDisplay.Add(new NameDisplay(num, gameObject, vector, this.esp.players[i].get_playerID().get_playerName()));
							}
						}
					}
				}
			}
			bool items_Name = this.esp.items_Name;
			if (items_Name)
			{
				for (int j = 0; j < this.itemFilter.Count; j++)
				{
					bool flag4 = this.itemFilter[j] != null && this.itemFilter[j].get_gameObject() != null && this.itemFilter[j].asset != null;
					if (flag4)
					{
						GameObject gameObject2 = this.itemFilter[j].get_gameObject();
						float num2 = (float)Math.Round((double)tool_ToolZ.getDistance(gameObject2.get_transform().get_position()), 0);
						bool flag5 = num2 <= this.esp.distance;
						if (flag5)
						{
							Vector3 vector2 = Camera.get_main().WorldToScreenPoint(gameObject2.get_transform().get_position());
							bool flag6 = vector2.z > 0f && vector2.y < (float)(Screen.get_width() - 2);
							if (flag6)
							{
								vector2.y = (float)Screen.get_height() - (vector2.y + 1f);
								vector2.x -= 32f;
								this.renderDisplay.Add(new NameDisplay(num2, gameObject2, vector2, this.itemFilter[j].asset.get_itemName()));
							}
						}
					}
				}
			}
			bool cars_Name = this.esp.cars_Name;
			if (cars_Name)
			{
				for (int k = 0; k < this.esp.vehicles.Length; k++)
				{
					bool flag7 = this.esp.vehicles[k] != null && this.esp.vehicles[k].get_gameObject() != null && this.esp.vehicles[k].get_asset() != null && this.esp.vehicles[k].health > 0;
					if (flag7)
					{
						GameObject gameObject3 = this.esp.vehicles[k].get_gameObject();
						float num3 = (float)Math.Round((double)tool_ToolZ.getDistance(gameObject3.get_transform().get_position()), 0);
						bool flag8 = num3 <= this.esp.distance;
						if (flag8)
						{
							Vector3 vector3 = Camera.get_main().WorldToScreenPoint(gameObject3.get_transform().get_position());
							bool flag9 = vector3.z > 0f && vector3.y < (float)(Screen.get_width() - 2);
							if (flag9)
							{
								vector3.y = (float)Screen.get_height() - (vector3.y + 1f);
								vector3.x -= 32f;
								this.renderDisplay.Add(new NameDisplay(num3, gameObject3, vector3, string.Concat(new object[]
								{
									this.esp.vehicles[k].get_asset().get_vehicleName(),
									" [",
									this.esp.vehicles[k].fuel,
									"]"
								})));
							}
						}
					}
				}
			}
		}

		public void update()
		{
			DateTime arg_07_0 = this.lastTime;
			bool flag = (DateTime.Now - this.lastTime).TotalMilliseconds >= 1000.0;
			if (flag)
			{
				bool enabled = this.esp.enabled;
				if (enabled)
				{
					this.update_Player();
					this.update_Zombie();
					this.update_Animals();
					this.update_Storages();
					this.update_Items();
					this.update_Cars();
				}
				this.lastTime = DateTime.Now;
			}
			bool arg_E1_0;
			if (this.esp.enabled && (this.esp.players_Name || this.esp.items_Name || this.esp.cars_Name))
			{
				DateTime arg_B4_0 = this.lastRendTime;
				arg_E1_0 = ((DateTime.Now - this.lastRendTime).TotalMilliseconds >= (double)this.esp.ref_Rate);
			}
			else
			{
				arg_E1_0 = false;
			}
			bool flag2 = arg_E1_0;
			if (flag2)
			{
				this.update_Name_Display();
				this.lastRendTime = DateTime.Now;
			}
			bool arg_143_0;
			if (this.esp.enabled && this.esp.show_Items)
			{
				DateTime arg_119_0 = this.lastFilterTime;
				arg_143_0 = ((DateTime.Now - this.lastFilterTime).TotalMilliseconds >= 1500.0);
			}
			else
			{
				arg_143_0 = false;
			}
			bool flag3 = arg_143_0;
			if (flag3)
			{
				this.update_ItemFilter();
				this.lastFilterTime = DateTime.Now;
			}
			bool flag4 = !this.esp.enabled && this.esp.ho.Count > 0;
			if (flag4)
			{
				for (int i = 0; i < this.esp.ho.Count; i++)
				{
					Object.Destroy(this.esp.ho[i].h);
					this.esp.ho.Remove(this.esp.ho[i]);
				}
			}
		}

		public void gui()
		{
			bool flag = Event.get_current().get_type() == 7;
			if (flag)
			{
				bool flag2 = this.esp.enabled && (this.esp.players_Name || this.esp.items_Name || this.esp.cars_Name);
				if (flag2)
				{
					for (int i = 0; i < this.renderDisplay.Count; i++)
					{
						this.DrawLabel(this.renderDisplay[i].rPos, this.renderDisplay[i].name, 0f);
						int num = 1;
						bool get_Distance = this.esp.get_Distance;
						if (get_Distance)
						{
							this.DrawLabel(this.renderDisplay[i].rPos, "Distance: " + this.renderDisplay[i].distance, 12f * (float)num);
							num++;
						}
					}
				}
			}
		}
	}
}
