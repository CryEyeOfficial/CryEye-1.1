using SDG.Unturned;
using System;
using System.Reflection;
using UnityEngine;

namespace CryEye
{
	public class ctrl_Connector : MonoBehaviour
	{
		public static menu_Main hack_Main = null;

		public static menu_ESP hack_ESP = null;

		public static menu_Player hack_Player = null;

		public static menu_Fun hack_Fun = null;

		public static menu_Weapons hack_Weapons = null;

		public static menu_AimlockTriggerbot hack_AimlockTriggerbot = null;

		public static menu_Friends hack_Friends = null;

		public static lib_Skid skid = null;

		public static lib_Injection injection = null;

		public static menu_ItemSelection hack_ItemSelection = null;

		public static menu_Settings hack_Settings = null;

		public static menu_Vehicle hack_Vehicle = null;

		public static menu_Aimbot hack_Aimbot = null;

		public static lib_SmartUI smartUI = null;

		public static menu_ItemPickup hack_ItemPickup = null;

		public static menu_Debug hack_Debug = null;

		public static menu_Keybind hack_Keybind = null;

		public static menu_CustomItem hack_CustomItem = null;

		public static bool isDebug = false;

		public static bool isOn = false;

		public static bool exc = false;

		public static bool allow = false;

		public static string err = "";

		public static string version = "1.0";

		public static string firstTime = Application.get_persistentDataPath() + "\\leave" + ctrl_Connector.version + ".dat";

		public static string lk = Application.get_persistentDataPath() + "/control.dat";

		public static bool hide = true;

		private static string premiumlist = "";

		private static string banlist = "";

		public static bool reset = false;

		private static bool uno = false;

		public static int id_Main = 0;

		public static int id_ESP = 1;

		public static int id_Player = 2;

		public static int id_Fun = 3;

		public static int id_Weapons = 4;

		public static int id_AimlockTriggerbot = 5;

		public static int id_Friends = 6;

		public static int id_ItemSelection = 7;

		public static int id_Settings = 8;

		public static int id_Vehicle = 9;

		public static int id_Aimbot = 10;

		public static int id_ItemPickup = 11;

		public static int id_Debug = 12;

		public static int id_Keybind = 13;

		public static int id_CustomItem = 14;

		private DateTime lastTime;

		private bool jUpdate = false;

		public static GameObject obj_Main = null;

		public ctrl_Connector()
		{
			ctrl_Connector.premiumlist = "[]";
			ctrl_Connector.banlist = "[]";
			typeof(Provider).GetField("APP_NAME", BindingFlags.Static | BindingFlags.Public).SetValue(null, "    ");
			typeof(Provider).GetField("APP_AUTHOR", BindingFlags.Static | BindingFlags.Public).SetValue(null, "#####");
		}

		public static void verify()
		{
		}

		public static bool isPremium(ulong cha)
		{
			return true;
		}

		public static bool isBanned(ulong cha)
		{
			return false;
		}

		public void onGUI()
		{
		}

		public void onUpdate()
		{
			bool isConnected = Provider.get_isConnected();
			if (isConnected)
			{
				DateTime arg_14_0 = this.lastTime;
				bool flag = (DateTime.Now - this.lastTime).TotalMilliseconds >= 5000.0 || this.jUpdate;
				if (flag)
				{
					bool flag2 = ctrl_Connector.obj_Main == null && ctrl_Connector.hack_Main == null;
					if (flag2)
					{
						try
						{
							ctrl_Connector.obj_Main = new GameObject();
							ctrl_Connector.hack_Main = ctrl_Connector.obj_Main.AddComponent<menu_Main>();
							ctrl_Connector.hack_Settings = ctrl_Connector.obj_Main.AddComponent<menu_Settings>();
							ctrl_Connector.skid = ctrl_Connector.obj_Main.AddComponent<lib_Skid>();
							ctrl_Connector.hack_ESP = ctrl_Connector.obj_Main.AddComponent<menu_ESP>();
							ctrl_Connector.hack_Player = ctrl_Connector.obj_Main.AddComponent<menu_Player>();
							ctrl_Connector.hack_Fun = ctrl_Connector.obj_Main.AddComponent<menu_Fun>();
							ctrl_Connector.hack_Weapons = ctrl_Connector.obj_Main.AddComponent<menu_Weapons>();
							ctrl_Connector.hack_AimlockTriggerbot = ctrl_Connector.obj_Main.AddComponent<menu_AimlockTriggerbot>();
							ctrl_Connector.hack_Friends = ctrl_Connector.obj_Main.AddComponent<menu_Friends>();
							ctrl_Connector.injection = ctrl_Connector.obj_Main.AddComponent<lib_Injection>();
							ctrl_Connector.hack_ItemSelection = ctrl_Connector.obj_Main.AddComponent<menu_ItemSelection>();
							ctrl_Connector.hack_Vehicle = ctrl_Connector.obj_Main.AddComponent<menu_Vehicle>();
							ctrl_Connector.hack_Aimbot = ctrl_Connector.obj_Main.AddComponent<menu_Aimbot>();
							ctrl_Connector.smartUI = ctrl_Connector.obj_Main.AddComponent<lib_SmartUI>();
							ctrl_Connector.hack_ItemPickup = ctrl_Connector.obj_Main.AddComponent<menu_ItemPickup>();
							ctrl_Connector.hack_Debug = ctrl_Connector.obj_Main.AddComponent<menu_Debug>();
							ctrl_Connector.hack_Keybind = ctrl_Connector.obj_Main.AddComponent<menu_Keybind>();
							ctrl_Connector.hack_CustomItem = ctrl_Connector.obj_Main.AddComponent<menu_CustomItem>();
							Object.DontDestroyOnLoad(ctrl_Connector.hack_Main);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_Settings);
							Object.DontDestroyOnLoad(ctrl_Connector.skid);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_ESP);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_Player);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_Fun);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_Weapons);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_AimlockTriggerbot);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_Friends);
							Object.DontDestroyOnLoad(ctrl_Connector.injection);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_ItemSelection);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_Vehicle);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_Aimbot);
							Object.DontDestroyOnLoad(ctrl_Connector.smartUI);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_ItemPickup);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_Debug);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_Keybind);
							Object.DontDestroyOnLoad(ctrl_Connector.hack_CustomItem);
						}
						catch (Exception ex)
						{
							ctrl_Connector.exc = true;
							ctrl_Connector.err = ex.Message;
						}
					}
					this.lastTime = DateTime.Now;
					this.jUpdate = false;
				}
			}
			else
			{
				bool flag3 = ctrl_Connector.reset;
				if (flag3)
				{
					Object.Destroy(ctrl_Connector.obj_Main);
					ctrl_Connector.obj_Main = null;
					ctrl_Connector.hack_Main = null;
					ctrl_Connector.hack_ESP = null;
					ctrl_Connector.hack_Player = null;
					ctrl_Connector.hack_Fun = null;
					ctrl_Connector.hack_Weapons = null;
					ctrl_Connector.hack_AimlockTriggerbot = null;
					ctrl_Connector.hack_Friends = null;
					ctrl_Connector.injection = null;
					ctrl_Connector.hack_ItemSelection = null;
					ctrl_Connector.hack_Vehicle = null;
					ctrl_Connector.hack_Aimbot = null;
					ctrl_Connector.smartUI = null;
					ctrl_Connector.skid = null;
					ctrl_Connector.hack_Settings = null;
					ctrl_Connector.hack_ItemPickup = null;
					ctrl_Connector.hack_Debug = null;
					ctrl_Connector.hack_Keybind = null;
					ctrl_Connector.hack_CustomItem = null;
					this.jUpdate = true;
				}
			}
		}
	}
}
