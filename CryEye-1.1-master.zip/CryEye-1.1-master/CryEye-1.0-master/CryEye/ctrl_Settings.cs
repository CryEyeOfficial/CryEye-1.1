using System;
using UnityEngine;

namespace CryEye
{
	public class ctrl_Settings
	{
		public static KeyCode menu_Main_key = 282;

		public static KeyCode menu_Easter = 285;

		public static Color esp_Zombie_color = Color.get_red();

		public static Color esp_Player_color = Color.get_red();

		public static Color esp_Animal_color = Color.get_blue();

		public static Color esp_Car_color = Color.get_cyan();

		public static Color esp_Friend_color = Color.get_green();

		public static Color esp_Storage_color = Color.get_magenta();

		public static Color esp_Item_color = Color.get_yellow();

		public static string name_menu_Main_key = "key_mainMenu";
	}
}
