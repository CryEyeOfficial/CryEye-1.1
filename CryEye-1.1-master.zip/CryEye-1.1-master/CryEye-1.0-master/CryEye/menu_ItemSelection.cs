using System;
using UnityEngine;

namespace CryEye
{
	public class menu_ItemSelection : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 10f);

		public bool clothing = false;

		public bool guns = false;

		public bool melee = false;

		public bool ammo = false;

		public bool foodnwater = false;

		public bool attachments = false;

		public bool bags = false;

		public bool throwable = false;

		public bool other = false;

		public bool medical = false;

		public bool custom = false;

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
		}

		public void Update()
		{
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_ItemSelection, this.window_Main, new GUI.WindowFunction(this.onWindow), "Item Selection Menu", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			this.guns = GUILayout.Toggle(this.guns, "Guns", new GUILayoutOption[0]);
			this.melee = GUILayout.Toggle(this.melee, "Melee", new GUILayoutOption[0]);
			this.ammo = GUILayout.Toggle(this.ammo, "Ammo", new GUILayoutOption[0]);
			this.attachments = GUILayout.Toggle(this.attachments, "Attachments", new GUILayoutOption[0]);
			this.throwable = GUILayout.Toggle(this.throwable, "Throwables", new GUILayoutOption[0]);
			this.clothing = GUILayout.Toggle(this.clothing, "Clothing", new GUILayoutOption[0]);
			this.bags = GUILayout.Toggle(this.bags, "Backpacks", new GUILayoutOption[0]);
			this.medical = GUILayout.Toggle(this.medical, "Medical", new GUILayoutOption[0]);
			this.foodnwater = GUILayout.Toggle(this.foodnwater, "Food and Water", new GUILayoutOption[0]);
			this.custom = GUILayout.Toggle(this.custom, "Custom", new GUILayoutOption[0]);
			bool flag = GUILayout.Button("Custom Editor", new GUILayoutOption[0]);
			if (flag)
			{
				ctrl_Connector.hack_CustomItem.toggleOn();
			}
			bool flag2 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag2)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}
	}
}
