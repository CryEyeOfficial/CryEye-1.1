using SDG.Unturned;
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CryEye
{
	public class lib_SmartUI : MonoBehaviour
	{
		private List<string> displayInfo = new List<string>();

		private bool hasCrack = true;

		private Interactable inte;

		private Rect info_window = new Rect((float)(Screen.get_width() - 500), (float)(Screen.get_height() - 200), 500f, 200f);

		private bool enabled = false;

		private DateTime lastCheck;

		public void Start()
		{
		}

		public void Update()
		{
			DateTime arg_07_0 = this.lastCheck;
			bool flag = (DateTime.Now - this.lastCheck).TotalMilliseconds >= 1500.0;
			if (flag)
			{
				this.lastCheck = DateTime.Now;
			}
			bool flag2 = this.enabled;
			if (flag2)
			{
				this.displayInfo.Clear();
				bool flag3 = PlayerInteract.get_interactable() != null;
				if (flag3)
				{
					bool flag4 = PlayerInteract.get_interactable() is InteractableStorage;
					if (flag4)
					{
						InteractableStorage interactableStorage = (InteractableStorage)PlayerInteract.get_interactable();
						this.displayInfo.Add("Type: Storage");
						this.displayInfo.Add("Locked: " + (this.getLocked(interactableStorage) ? "Yes" : "No"));
						this.displayInfo.Add("HasItems: " + ((interactableStorage.get_items().getItemCount() > 0) ? "Yes" : "No"));
						int display = this.getDisplay();
						this.info_window.set_width((float)display);
						this.info_window.set_x((float)(Screen.get_width() - display - 10));
						this.inte = PlayerInteract.get_interactable();
					}
					else
					{
						bool flag5 = PlayerInteract.get_interactable() is InteractableDoor;
						if (flag5)
						{
							InteractableDoor storage = (InteractableDoor)PlayerInteract.get_interactable();
							this.displayInfo.Add("Type: Door");
							this.displayInfo.Add("Locked: " + (this.getLocked(storage) ? "Yes" : "No"));
							int display2 = this.getDisplay();
							this.info_window.set_width((float)display2);
							this.info_window.set_x((float)(Screen.get_width() - display2 - 10));
							this.inte = PlayerInteract.get_interactable();
						}
					}
				}
				else
				{
					this.hasCrack = false;
					RaycastHit raycastHit;
					bool lookingAt = tool_ToolZ.getLookingAt(out raycastHit, float.PositiveInfinity);
					if (lookingAt)
					{
						bool flag6 = DamageTool.getPlayer(raycastHit.get_transform()) && DamageTool.getPlayer(raycastHit.get_transform()) != tool_ToolZ.getLocalPlayer();
						if (flag6)
						{
							Player player = DamageTool.getPlayer(raycastHit.get_transform());
							this.displayInfo.Add("Type: Player");
							this.displayInfo.Add("Name: " + player.get_name());
							this.displayInfo.Add("Health: " + player.get_life().get_health());
							this.displayInfo.Add("Food: " + player.get_life().get_food());
							this.displayInfo.Add("Water: " + player.get_life().get_water());
							this.displayInfo.Add("Stamina: " + player.get_life().get_stamina());
							this.displayInfo.Add("Distance: " + Math.Round((double)tool_ToolZ.getDistance(player.get_transform().get_position()), 0));
							bool flag7 = tool_ToolZ.getLocalPlayer().get_equipment().get_asset() != null && tool_ToolZ.getLocalPlayer().get_equipment().get_asset() is ItemWeaponAsset;
							if (flag7)
							{
								this.displayInfo.Add("Will hit: " + ((tool_ToolZ.getDistance(player.get_transform().get_position()) <= ((ItemWeaponAsset)tool_ToolZ.getLocalPlayer().get_equipment().get_asset()).range) ? "Yes" : "No"));
							}
							int display3 = this.getDisplay();
							this.info_window.set_width((float)display3);
							this.info_window.set_x((float)(Screen.get_width() - display3 - 10));
						}
						else
						{
							bool flag8 = DamageTool.getZombie(raycastHit.get_transform());
							if (flag8)
							{
								Zombie zombie = DamageTool.getZombie(raycastHit.get_transform());
								this.displayInfo.Add("Type: Zombie");
								this.displayInfo.Add("Health: " + this.getHealth(zombie));
								this.displayInfo.Add("Distance: " + Math.Round((double)tool_ToolZ.getDistance(zombie.get_transform().get_position()), 0));
								bool flag9 = tool_ToolZ.getLocalPlayer().get_equipment().get_asset() != null && tool_ToolZ.getLocalPlayer().get_equipment().get_asset() is ItemWeaponAsset;
								if (flag9)
								{
									this.displayInfo.Add("Will hit: " + ((tool_ToolZ.getDistance(zombie.get_transform().get_position()) <= ((ItemWeaponAsset)tool_ToolZ.getLocalPlayer().get_equipment().get_asset()).range) ? "Yes" : "No"));
								}
								int display4 = this.getDisplay();
								this.info_window.set_width((float)display4);
								this.info_window.set_x((float)(Screen.get_width() - display4 - 10));
							}
							else
							{
								bool flag10 = DamageTool.getAnimal(raycastHit.get_transform());
								if (flag10)
								{
									Animal animal = DamageTool.getAnimal(raycastHit.get_transform());
									this.displayInfo.Add("Type: Animal");
									this.displayInfo.Add("Health: " + this.getHealth(animal));
									this.displayInfo.Add("Distance: " + Math.Round((double)tool_ToolZ.getDistance(animal.get_transform().get_position()), 0));
									bool flag11 = tool_ToolZ.getLocalPlayer().get_equipment().get_asset() != null && tool_ToolZ.getLocalPlayer().get_equipment().get_asset() is ItemWeaponAsset;
									if (flag11)
									{
										this.displayInfo.Add("Will hit: " + ((tool_ToolZ.getDistance(animal.get_transform().get_position()) <= ((ItemWeaponAsset)tool_ToolZ.getLocalPlayer().get_equipment().get_asset()).range) ? "Yes" : "No"));
									}
									int display5 = this.getDisplay();
									this.info_window.set_width((float)display5);
									this.info_window.set_x((float)(Screen.get_width() - display5 - 10));
								}
							}
						}
					}
				}
			}
		}

		public void OnGUI()
		{
			bool flag = this.displayInfo.Count > 0 && this.enabled;
			if (flag)
			{
				GUILayout.BeginArea(this.info_window);
				for (int i = 0; i < this.displayInfo.Count; i++)
				{
					GUILayout.Label(this.displayInfo[i], new GUILayoutOption[0]);
				}
				bool flag2 = this.hasCrack;
				if (flag2)
				{
					bool flag3 = GUILayout.Button("Crack/Unlock", new GUILayoutOption[0]);
					if (flag3)
					{
						this.setLocked(this.inte, false);
					}
				}
				GUILayout.EndArea();
			}
		}

		private int getDisplay()
		{
			int num = -2147483648;
			for (int i = 0; i < this.displayInfo.Count; i++)
			{
				bool flag = this.displayInfo[i].Length > num;
				if (flag)
				{
					num = this.displayInfo[i].Length;
				}
			}
			bool flag2 = this.hasCrack;
			if (flag2)
			{
				bool flag3 = 12 > num;
				if (flag3)
				{
					num = 12;
				}
			}
			return num * 12;
		}

		private ushort getHealth(object obj)
		{
			return (ushort)obj.GetType().GetField("health", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(obj);
		}

		private bool getLocked(Interactable storage)
		{
			return (bool)storage.GetType().GetField("isLocked", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(storage);
		}

		private void setLocked(Interactable storage, bool locked)
		{
			storage.GetType().GetField("isLocked", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(storage, locked);
		}
	}
}
