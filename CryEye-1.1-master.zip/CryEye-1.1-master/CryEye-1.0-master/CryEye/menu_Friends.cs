using SDG.Unturned;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace CryEye
{
	public class menu_Friends : MonoBehaviour
	{
		private bool isOn;

		private Rect window_Main = new Rect(10f, 10f, 200f, 200f);

		private Vector2 scroll;

		public bool sw = false;

		private List<Friend> friends = new List<Friend>();

		public bool getIsOn()
		{
			return this.isOn;
		}

		public void setIsOn(bool a)
		{
			this.isOn = a;
		}

		public void toggleOn()
		{
			this.isOn = !this.isOn;
		}

		public void Start()
		{
			this.isOn = false;
			this.loadFriends();
		}

		public void Update()
		{
		}

		public void OnGUI()
		{
			bool flag = this.isOn && ctrl_Connector.isOn;
			if (flag)
			{
				this.window_Main = GUILayout.Window(ctrl_Connector.id_Friends, this.window_Main, new GUI.WindowFunction(this.onWindow), "Friends Menu", new GUILayoutOption[0]);
			}
		}

		public void onWindow(int ID)
		{
			this.window_Main.set_width(200f);
			this.scroll = GUILayout.BeginScrollView(this.scroll, new GUILayoutOption[0]);
			bool flag = this.sw;
			if (flag)
			{
				SteamPlayer[] array = Provider.get_clients().ToArray();
				for (int i = 0; i < array.Length; i++)
				{
					SteamPlayer steamPlayer = array[i];
					bool flag2 = !this.isFriend(steamPlayer) && steamPlayer.get_player() != tool_ToolZ.getLocalPlayer();
					if (flag2)
					{
						bool flag3 = (float)(steamPlayer.get_playerID().get_playerName().Length * 12) > this.window_Main.get_width();
						if (flag3)
						{
							this.window_Main.set_width((float)(steamPlayer.get_playerID().get_playerName().Length * 12));
						}
						bool flag4 = GUILayout.Button(steamPlayer.get_playerID().get_playerName(), new GUILayoutOption[0]);
						if (flag4)
						{
							this.addFriend(steamPlayer);
						}
					}
				}
			}
			else
			{
				try
				{
					foreach (Friend current in this.friends)
					{
						bool flag5 = (float)(current.displayName.Length * 12) > this.window_Main.get_width();
						if (flag5)
						{
							this.window_Main.set_width((float)(current.displayName.Length * 12));
						}
						bool flag6 = GUILayout.Button(current.displayName, new GUILayoutOption[0]);
						if (flag6)
						{
							this.removeFriend(current);
						}
					}
				}
				catch (Exception var_11_194)
				{
					lib_FileSystem.deleteFriends();
					this.loadFriends();
				}
			}
			GUILayout.EndScrollView();
			bool flag7 = GUILayout.Button("Close Menu", new GUILayoutOption[0]);
			if (flag7)
			{
				this.toggleOn();
			}
			GUI.DragWindow();
		}

		public void loadFriends()
		{
			bool flag = lib_FileSystem.existFriends();
			if (flag)
			{
				try
				{
					this.friends = lib_FileSystem.readFriends();
				}
				catch (Exception var_1_1A)
				{
					lib_FileSystem.deleteFriends();
					this.loadFriends();
				}
			}
			else
			{
				lib_FileSystem.createFriends();
			}
		}

		public void saveFriends()
		{
			lib_FileSystem.writeFriends(this.friends.ToArray());
		}

		public void addFriend(SteamPlayer player)
		{
			this.friends.Add(new Friend(player.get_player().get_name(), player.get_playerID().get_playerName(), player.get_playerID().get_steamID().m_SteamID));
			this.saveFriends();
		}

		public bool isFriend(SteamPlayer player)
		{
			return Array.Exists<Friend>(this.friends.ToArray(), (Friend a) => a.ID == player.get_playerID().get_steamID().m_SteamID);
		}

		public bool isFriend(Player player)
		{
			return Array.Exists<Friend>(this.friends.ToArray(), (Friend a) => a.ID == tool_ToolZ.getPlayerID(player));
		}

		public void removeFriend(Friend f)
		{
			this.friends.Remove(f);
			this.saveFriends();
		}

		public Friend[] getFriends()
		{
			return this.friends.ToArray();
		}
	}
}
