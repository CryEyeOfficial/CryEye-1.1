using System;

namespace CryEye
{
	public class Setting
	{
		public string name;

		public object value;

		public int type;

		public Setting(string name, object value, int type)
		{
			this.name = name;
			this.value = value;
			this.type = type;
		}
	}
}
